/* global React, Titlebar, Footer, Key, Logo, PixelIcon, Annotation */
// Inline dialogs / warnings — 4 variations.

// V1 — Inline expansion under the offending button (replaces dialog modal)
function DialogV1() {
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}><Logo /></div>
      <div style={{ flex: 1, padding: 18 }}>
        <div className="wf-section-label">Actions</div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <button className="wf-btn green" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="play" color="var(--c-play)" size={20} /><span>Play</span></button>
          <div style={{ flex: 1 }}>
            <button className="wf-btn focus" style={{ minHeight: 86, width: '100%', borderColor: 'var(--c-warn)', color: 'var(--c-warn)' }}>
              <PixelIcon shape="upload" color="var(--c-warn)" size={18} />
              <span>Upload Logs</span>
            </button>
            {/* Inline callout — drops down attached to its button */}
            <div className="wf-box thick" style={{ marginTop: 6, padding: 12, borderColor: 'var(--c-warn)', borderStyle: 'solid', position: 'relative', background: 'rgba(251,191,36,0.1)' }}>
              <div style={{ position: 'absolute', top: -8, left: 24, width: 14, height: 14, background: '#fff7e8', borderTop: '3px solid var(--c-warn)', borderLeft: '3px solid var(--c-warn)', transform: 'rotate(45deg)' }} />
              <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 18, color: 'var(--c-warn)', marginBottom: 4 }}>⚠ Only inside Minecraft</div>
              <div className="wf-note" style={{ fontSize: 14, fontStyle: 'normal', color: 'var(--ink)' }}>
                Place this JAR in <code style={{ fontFamily: 'var(--mono)' }}>mods/</code> and run Minecraft to upload logs.
              </div>
              <div style={{ marginTop: 8, display: 'flex', gap: 6 }}>
                <button className="wf-btn" style={{ minHeight: 28, fontSize: 13, padding: '2px 10px' }}>Got it</button>
                <button className="wf-btn" style={{ minHeight: 28, fontSize: 13, padding: '2px 10px' }}>Open mods/ folder</button>
              </div>
            </div>
          </div>
          <button className="wf-btn blue" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="broom" color="var(--c-info)" size={18} /><span>Cleanup</span></button>
          <button className="wf-btn red" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="x" color="var(--c-danger)" size={16} /><span>Exit</span></button>
        </div>
        <Annotation arrow="up" style={{ marginTop: 14 }}>Dropdown attached to the button — page never goes modal.</Annotation>
      </div>
      <Footer><Key>↵</Key>/<Key>ESC</Key> Dismiss</Footer>
    </div>
  );
}

// V2 — Disabled state from the start; tooltip-on-hover instead of click-then-warn
function DialogV2() {
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}><Logo /></div>
      <div style={{ flex: 1, padding: 18 }}>
        <div className="wf-section-label">Actions</div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="wf-btn green focus" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="play" color="var(--c-play)" size={20} /><span>Play</span></button>

          <div style={{ flex: 1, position: 'relative' }}>
            <button className="wf-btn" style={{ minHeight: 86, width: '100%', opacity: 0.45, cursor: 'not-allowed', borderStyle: 'dashed' }}>
              <PixelIcon shape="upload" size={18} />
              <span>Upload Logs</span>
              <span className="wf-note" style={{ fontSize: 11 }}>🔒 minecraft only</span>
            </button>
            {/* Hover tooltip */}
            <div className="wf-box" style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 6, padding: 8, background: 'var(--ink)', color: 'var(--paper)', fontFamily: 'var(--mono)', fontSize: 12 }}>
              ℹ requires Minecraft runtime. install JAR in mods/.
            </div>
          </div>

          <button className="wf-btn blue" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="broom" color="var(--c-info)" size={18} /><span>Cleanup</span></button>
          <button className="wf-btn red" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="x" color="var(--c-danger)" size={16} /><span>Exit</span></button>
        </div>
        <Annotation arrow="up" style={{ marginTop: 14 }}>Prevent the error before it happens. Disable + tooltip explains why.</Annotation>
      </div>
      <Footer><Key>?</Key> Why disabled</Footer>
    </div>
  );
}

// V3 — Toast banner top-right, non-blocking
function DialogV3() {
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}><Logo /></div>
      <div style={{ flex: 1, padding: 18, position: 'relative' }}>
        <div className="wf-section-label">Actions</div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="wf-btn green" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="play" color="var(--c-play)" size={20} /><span>Play</span></button>
          <button className="wf-btn focus" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="upload" size={18} /><span>Upload Logs</span></button>
          <button className="wf-btn blue" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="broom" color="var(--c-info)" size={18} /><span>Cleanup</span></button>
          <button className="wf-btn red" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="x" color="var(--c-danger)" size={16} /><span>Exit</span></button>
        </div>

        {/* Toast */}
        <div className="wf-box thick" style={{ position: 'absolute', top: 12, right: 18, width: 320, padding: 12, borderColor: 'var(--c-warn)', background: '#fff7e8' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 17, color: 'var(--c-warn)' }}>⚠ Feature unavailable</div>
            <span className="wf-note" style={{ fontSize: 11 }}>5s ●●●○○</span>
          </div>
          <div className="wf-note" style={{ fontSize: 13, fontStyle: 'normal', color: 'var(--ink)', marginTop: 4 }}>
            Upload Logs requires Minecraft. Install in mods/ folder.
          </div>
          <div style={{ marginTop: 8, display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
            <button className="wf-btn" style={{ minHeight: 26, fontSize: 12, padding: '2px 8px' }}>Dismiss</button>
            <button className="wf-btn blue" style={{ minHeight: 26, fontSize: 12, padding: '2px 8px' }}>Help →</button>
          </div>
        </div>

        <Annotation arrow="up" style={{ marginTop: 30 }}>Non-blocking toast w/ auto-dismiss timer. Stack vertically.</Annotation>
      </div>
      <Footer><Key>ESC</Key> Dismiss toast</Footer>
    </div>
  );
}

// V4 — Status strip at bottom (terminal feel), inline severity colors
function DialogV4() {
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}><Logo /></div>
      <div style={{ flex: 1, padding: 18 }}>
        <div className="wf-section-label">Actions</div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="wf-btn green" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="play" color="var(--c-play)" size={20} /><span>Play</span></button>
          <button className="wf-btn focus" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="upload" size={18} /><span>Upload Logs</span></button>
          <button className="wf-btn blue" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="broom" color="var(--c-info)" size={18} /><span>Cleanup</span></button>
          <button className="wf-btn red" style={{ minHeight: 86, flex: 1 }}><PixelIcon shape="x" color="var(--c-danger)" size={16} /><span>Exit</span></button>
        </div>
        <Annotation arrow="down" style={{ marginTop: 14 }}>All advisories funnel into a single status line at bottom.</Annotation>
      </div>

      {/* Persistent status strip above footer */}
      <div style={{ background: 'var(--c-warn)', color: '#fff', padding: '8px 14px', fontFamily: 'var(--mono)', fontSize: 14, display: 'flex', gap: 12, alignItems: 'center' }}>
        <span style={{ fontWeight: 700 }}>WARN</span>
        <span>Upload Logs is Minecraft-only. Drop the JAR in /mods to enable.</span>
        <span style={{ marginLeft: 'auto', opacity: 0.85 }}>[ docs ]  [ × ]</span>
      </div>
      <Footer><Key>F1</Key> Open docs · <Key>ESC</Key> Hide</Footer>
    </div>
  );
}

Object.assign(window, { DialogV1, DialogV2, DialogV3, DialogV4 });

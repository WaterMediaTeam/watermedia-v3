/* global React, Titlebar, Footer, Header, BackendStrip, K, PixIcon, LineIcon, VideoSurface */
const { useState } = React;

function MainScreen({ density = 'cozy', initialPopup = null }) {
  const [hoverDisabled, setHoverDisabled] = useState(false);
  const [popup, setPopup] = useState(initialPopup); // null | 'open' | 'upload'

  const tests = [
    { id: 'platforms',     name: 'Platforms',     n: 4,  color: 'var(--neon)' },
    { id: 'webp-lossy',    name: 'WEBP lossy',    n: 9,  color: 'var(--cyan)' },
    { id: 'webp-lossless', name: 'WEBP lossless', n: 6,  color: 'var(--cyan)' },
    { id: 'gif',           name: 'GIF',           n: 12, color: 'var(--amber)' },
    { id: 'png',           name: 'PNG',           n: 8,  color: 'var(--neon-1)' },
    { id: 'video',         name: 'Video',         n: 5,  color: 'var(--green)' },
  ];

  return (
    <div className="app" data-density={density} style={{ position: 'relative' }}>
      <Titlebar />

      <Header
        name="Main menu"
        sub="multimedia api"
        right={<span className="tag">v2.0.0</span>}
      />

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, padding: 22, minHeight: 0 }}>
        {/* Actions */}
        <section style={{ display: 'flex', flexDirection: 'column', minHeight: 0 }}>
          <div className="sec-head">Actions <span className="count">4 available</span></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <button className="btn lg green focus" onClick={() => setPopup('open')}>
              <span className="glyph"><PixIcon name="play" size={14} color="var(--green)" /></span>
              <span>Play media</span>
              <span style={{ flex: 1 }} />
              <span className="hk">↵</span>
            </button>

            <div style={{ position: 'relative' }} onMouseEnter={() => setHoverDisabled(true)} onMouseLeave={() => setHoverDisabled(false)}>
              <button className="btn lg" style={{ width: '100%' }} onClick={() => setPopup('upload')}>
                <span className="glyph"><LineIcon name="upload" size={14} /></span>
                <span>Upload Logs</span>
                <span style={{ flex: 1 }} />
                <span className="hk">U</span>
              </button>
              {hoverDisabled && (
                <div className="tooltip amber" style={{ top: '100%', left: 0, marginTop: 8, whiteSpace: 'normal', maxWidth: 320 }}>
                  <div className="tt-arrow" style={{ top: -6, left: 18 }} />
                  <div className="tt-title">Sends logs to mclo.gs</div>
                  <div>Reads <span style={{ color: 'var(--amber)' }}>logs/latest.log</span> and any crash reports, then uploads.</div>
                </div>
              )}
            </div>

            <button className="btn lg blue">
              <span className="glyph"><PixIcon name="broom" size={14} color="var(--neon-1)" /></span>
              <span>Cleanup cache</span>
              <span style={{ flex: 1 }} />
              <span className="hk">412 MB</span>
            </button>

            <button className="btn lg red">
              <span className="glyph"><PixIcon name="x" size={12} color="var(--red)" /></span>
              <span>Exit</span>
              <span style={{ flex: 1 }} />
              <span className="hk">ESC</span>
            </button>
          </div>
        </section>

        {/* Media tests */}
        <section style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="sec-head">Media tests <span className="count">{tests.length} categories</span></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, alignContent: 'start' }}>
            {tests.map(t => (
              <button key={t.id} className="btn" style={{ flexDirection: 'column', alignItems: 'flex-start', padding: 12, gap: 6, minHeight: 76, textTransform: 'none' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: t.color }}>
                  <PixIcon name="folder" size={12} color={t.color} />
                  <span style={{ fontFamily: 'var(--mono)', fontSize: 13, letterSpacing: 1, textTransform: 'uppercase' }}>{t.name}</span>
                </div>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-faint)', textTransform: 'uppercase', letterSpacing: 1 }}>
                  {t.n} samples · click to load
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>

      <Footer
        left={<>
          <span><K>↑↓←→</K> Navigate</span>
          <span><K>↵</K> Select</span>
          <span><K>?</K> Help</span>
          <span><K>ESC</K> Exit</span>
        </>}
        right={<BackendStrip />}
      />

      {popup === 'open'   && <OpenMultimediaPopup onClose={() => setPopup(null)} />}
      {popup === 'upload' && <UploadLogsPopup    onClose={() => setPopup(null)} />}
    </div>
  );
}

// =================================================================
// OPEN MULTIMEDIA — preview thumb + URL+Paste, no separate clipboard row
// =================================================================
function OpenMultimediaPopup({ onClose }) {
  const [url, setUrl] = useState('https://youtube.com/watch?v=aurxn-balada');
  const valid = url.trim().length > 4;

  return (
    <PopupShell title="Open Multimedia" onClose={onClose} width={620} accent="blue">
      <div className="pop-body">
        {/* 1920×1080 preview frame with thumbnail + title */}
        <div className="tv is-focus" style={{ padding: 6, aspectRatio: '16 / 9' }}>
          <span className="corner bl" /><span className="corner br" />
          <div className="screen" style={{ position: 'relative', overflow: 'hidden' }}>
            <VideoSurface dim={!valid}>
              {valid ? (
                <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', padding: 16, background: 'linear-gradient(180deg, transparent 50%, rgba(6,9,26,0.85) 100%)' }}>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: 2, color: 'var(--cyan)', textTransform: 'uppercase', marginBottom: 4 }}>YouTube · 04:04</div>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 16, color: 'var(--neon-1)', letterSpacing: 1, textTransform: 'uppercase', textShadow: '0 0 10px var(--glow)' }}>LA BALADA DE AURONPLAY</div>
                </div>
              ) : (
                <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 8, color: 'var(--text-faint)', fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 2 }}>
                  <LineIcon name="link" size={28} />
                  <span>NO MEDIA</span>
                </div>
              )}
            </VideoSurface>
          </div>
          <div style={{ position: 'absolute', top: -1, right: 8, padding: '2px 6px', background: 'var(--bg-1)', border: '1px solid var(--cyan)', color: 'var(--cyan)', fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: 1.5 }}>1920×1080</div>
        </div>

        {/* URL + Paste */}
        <div className="pop-row">
          <label>URL or path</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <div className="pop-input" style={{ flex: 1 }}>
              <LineIcon name="link" size={12} />
              <input
                autoFocus
                value={url}
                onChange={e => setUrl(e.target.value)}
                placeholder="https://… or C:\path\to\file.mp4"
                spellCheck={false}
              />
            </div>
            <button
              className="btn"
              onClick={() => setUrl('https://youtube.com/watch?v=aurxn-balada')}
              title="Paste from clipboard"
            >
              <LineIcon name="link" size={11} /> Paste
            </button>
          </div>
        </div>

        {/* Small status chip */}
        <div style={{ display: 'flex' }}>
          <span className="status-chip" data-on={valid ? 1 : 0}>
            <span className={'pip ' + (valid ? 'ok' : '')} />
            {valid ? 'DETECTED · YouTube · stream' : 'Awaiting URL…'}
          </span>
        </div>
      </div>

      <div className="pop-foot">
        <button className="btn" onClick={onClose}>
          <span>Cancel</span><span className="hk">ESC</span>
        </button>
        <div style={{ flex: 1 }} />
        <button className="btn green focus" disabled={!valid} onClick={onClose}>
          <PixIcon name="play" size={11} color="var(--green)" />
          <span>Play</span>
          <span className="hk">↵</span>
        </button>
      </div>
    </PopupShell>
  );
}

// =================================================================
// UPLOAD LOGS — multi-step flow rendered as panels (NOT a console)
// =================================================================
function UploadLogsPopup({ onClose }) {
  // step: 'scan' | 'upload' | 'done'
  const [step, setStep] = useState('scan');

  // Files — only readable ones. NOT FOUND items hidden after scan.
  const files = [
    { name: 'latest.log',                    bytes: '957 B',   status: 'ok', url: 'https://mclo.gs/7FXnrLu' },
    { name: 'crash-2026-04-20_03.58.26.txt', bytes: '10.3 KB', status: 'ok', url: 'https://mclo.gs/INW0HSG' },
  ];
  const skipped = step === 'scan' ? [
    { name: 'watermedia-app.log', bytes: '—', status: 'err' },
  ] : [];

  const titleByStep = {
    scan: 'Upload Log Files',
    upload: 'Upload Log Files',
    done: 'Success',
  };
  const accentByStep = step === 'done' ? 'green' : 'cyan';

  // Fake progress per file in upload step (different to feel alive)
  const uploadProgress = [82, 64];

  return (
    <PopupShell title={titleByStep[step]} onClose={onClose} width={620} accent={accentByStep}>
      {/* Steps strip */}
      <div className="step-strip">
        <Step idx={1} label="Scan"      active={step === 'scan'}   done={step !== 'scan'} />
        <Step idx={2} label="Upload"    active={step === 'upload'} done={step === 'done'} />
        <Step idx={3} label="Issue"     active={step === 'done'}   done={step === 'done'} />
      </div>

      <div className="pop-body">
        {/* File list */}
        <div className="file-list">
          {files.map((f, i) => {
            if (step === 'scan') {
              return (
                <div key={f.name} className="file-row" data-status="ok">
                  <span className="pip ok" />
                  <span className="fr-name">{f.name}</span>
                  <span className="fr-bytes">{f.bytes}</span>
                  <span className="fr-status ok">READ OK</span>
                </div>
              );
            }
            if (step === 'upload') {
              const pct = uploadProgress[i];
              return (
                <div key={f.name} className="file-row uploading" data-status="load">
                  <span className="pip load" />
                  <span className="fr-name">{f.name}</span>
                  <span className="fr-bytes">{f.bytes}</span>
                  <span className="fr-status load">{pct}%</span>
                  <div className="fr-progress">
                    <div className="fr-progress-fill" style={{ width: pct + '%' }} />
                  </div>
                </div>
              );
            }
            // done
            return (
              <div key={f.name} className="file-row" data-status="ok">
                <span className="pip ok" />
                <span className="fr-name">{f.name}</span>
                <span className="fr-bytes">{f.bytes}</span>
                <span className="fr-status ok">UPLOADED</span>
                <a className="fr-link" href={f.url} onClick={e => e.preventDefault()}>{f.url}</a>
              </div>
            );
          })}
          {skipped.map(f => (
            <div key={f.name} className="file-row" data-status="err">
              <span className="pip err" />
              <span className="fr-name">{f.name}</span>
              <span className="fr-bytes">{f.bytes}</span>
              <span className="fr-status err">NOT FOUND</span>
            </div>
          ))}
        </div>

        {step === 'done' && (
          <div className="result-card">
            <div className="rc-row">
              <LineIcon name="check" size={14} />
              <span style={{ color: 'var(--green)' }}>Issue template copied to clipboard</span>
            </div>
            <div className="rc-row">
              <LineIcon name="link" size={14} />
              <a className="fr-link" href="#" onClick={e => e.preventDefault()}>github.com/watermedia/issues/new</a>
            </div>
            <div style={{ color: 'var(--text-soft)', fontSize: 11, marginTop: 4, fontFamily: 'var(--mono)' }}>
              Paste the template in the new issue body to share log links.
            </div>
          </div>
        )}
      </div>

      <div className="pop-foot">
        <button className="btn" onClick={onClose}>
          <span>{step === 'done' ? 'Close' : 'Cancel'}</span>
          <span className="hk">ESC</span>
        </button>
        <div style={{ flex: 1 }} />
        {step === 'scan' && (
          <button className="btn cyan focus" onClick={() => setStep('upload')}>
            <LineIcon name="upload" size={11} />
            <span>Upload to mclo.gs</span>
            <span className="hk">↵</span>
          </button>
        )}
        {step === 'upload' && (
          <button className="btn cyan focus" onClick={() => setStep('done')}>
            <LineIcon name="check" size={11} />
            <span>Generate report</span>
            <span className="hk">↵</span>
          </button>
        )}
        {step === 'done' && (
          <button className="btn green focus" onClick={onClose}>
            <LineIcon name="link" size={11} />
            <span>Open GitHub</span>
            <span className="hk">↵</span>
          </button>
        )}
      </div>
    </PopupShell>
  );
}

// =================================================================
// Shared popup chrome — TV-frame style modal
// =================================================================
function PopupShell({ title, onClose, width = 520, accent = 'blue', children }) {
  return (
    <div className="pop-overlay" onClick={onClose}>
      <div
        className={'pop-shell tv is-focus ' + accent}
        style={{ width }}
        onClick={e => e.stopPropagation()}
      >
        <span className="corner bl" /><span className="corner br" />
        <div className="pop-head">
          <span className="pop-title">{title}</span>
          <button className="pop-close" onClick={onClose} aria-label="Close">×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Step({ idx, label, active, done }) {
  return (
    <div className={'step ' + (active ? 'active' : '') + (done ? ' done' : '')}>
      <span className="step-idx">{done ? '✓' : idx}</span>
      <span className="step-label">{label}</span>
    </div>
  );
}

Object.assign(window, { MainScreen, OpenMultimediaPopup, UploadLogsPopup });

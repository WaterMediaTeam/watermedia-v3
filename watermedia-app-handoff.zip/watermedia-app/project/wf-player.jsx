/* global React, Titlebar, Footer, Key, PixelIcon, Annotation */
// Player screen — 4 variations.

// V1 — Collapsible debug drawer; HUD auto-fades; transport bar at bottom.
function PlayerV1() {
  return (
    <div className="wf" data-density="cozy" style={{ background: '#111' }}>
      <Titlebar />
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#222' }}>
        {/* Video surface */}
        <div className="crt" style={{ position: 'absolute', inset: 0, background: 'repeating-linear-gradient(45deg, #2a2a2a, #2a2a2a 8px, #1c1c1c 8px, #1c1c1c 16px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#666', fontFamily: 'var(--mono)' }}>
          [ video surface · 16:9 ]
        </div>

        {/* Top HUD */}
        <div style={{ position: 'absolute', top: 10, left: 10, right: 10, display: 'flex', gap: 8, alignItems: 'center' }}>
          <button className="wf-btn" style={{ minHeight: 30, fontSize: 12, padding: '2px 8px', background: 'rgba(0,0,0,0.6)', color: '#fff', borderColor: '#fff' }}>← Back</button>
          <div style={{ flex: 1, fontFamily: 'var(--hand-bold)', fontSize: 18, color: '#fff', textShadow: '0 1px 2px #000' }}>
            LA BALADA DE AURONPLAY <span className="wf-note" style={{ color: '#ccc' }}>· Lucas Requena · 4:04</span>
          </div>
          <button className="wf-btn" style={{ minHeight: 30, fontSize: 12, padding: '2px 8px', background: 'rgba(0,0,0,0.6)', color: '#fff', borderColor: '#fff' }}>ⓘ Debug</button>
        </div>

        {/* Collapsed debug drawer (handle on left) */}
        <div style={{ position: 'absolute', top: 60, left: 10, width: 32, height: 120, background: 'rgba(0,0,0,0.7)', border: '1.5px solid #fff', color: '#fff', fontFamily: 'var(--mono)', fontSize: 10, writingMode: 'vertical-rl', textAlign: 'center', padding: '6px 0', cursor: 'pointer' }}>
          ▶ DEBUG · MRL · ENGINE · STATUS
        </div>

        {/* Transport */}
        <div style={{ position: 'absolute', bottom: 10, left: 10, right: 10, background: 'rgba(0,0,0,0.7)', border: '1.5px solid #fff', padding: '6px 12px', display: 'flex', alignItems: 'center', gap: 12, color: '#fff', fontFamily: 'var(--mono)', fontSize: 12 }}>
          <PixelIcon shape="pause" color="#fff" size={14} />
          <span>00:01</span>
          <div style={{ flex: 1, height: 6, background: '#333', position: 'relative' }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '5%', background: 'var(--c-neon)' }} />
            <div style={{ position: 'absolute', left: '5%', top: -3, width: 12, height: 12, background: 'var(--c-neon)', border: '1px solid #fff' }} />
          </div>
          <span>04:04</span>
          <span>🔊 100%</span>
          <span>1.0×</span>
          <span>HD</span>
          <span>⛶</span>
        </div>

        <Annotation arrow="up" style={{ position: 'absolute', bottom: 60, right: 14, background: 'var(--paper)', padding: 4 }}>
          HUD fades after 3s · click anywhere to revive
        </Annotation>
      </div>
      <Footer><Key>SPACE</Key> Play/Pause · <Key>F</Key> Fullscreen · <Key>D</Key> Debug · <Key>ESC</Key> Back</Footer>
    </div>
  );
}

// V2 — Side rail layout: video + always-visible right panel for debug + sources.
function PlayerV2() {
  return (
    <div className="wf" data-density="cozy" style={{ background: '#111' }}>
      <Titlebar />
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <div style={{ flex: 1, position: 'relative', background: '#222', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#666', fontFamily: 'var(--mono)' }} className="crt">
          [ video ]
          {/* Mini transport overlay */}
          <div style={{ position: 'absolute', bottom: 8, left: 8, right: 8, background: 'rgba(0,0,0,0.7)', padding: '6px 10px', color: '#fff', fontFamily: 'var(--mono)', fontSize: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
            ▌▌ 00:01 ━━━●━━━━━━━━━━━━ 04:04  🔊 100%  1.0×  ⛶
          </div>
        </div>
        <aside style={{ width: 280, background: '#1a1a1a', color: '#ddd', borderLeft: '2px solid #444', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: 10, borderBottom: '1px solid #333', display: 'flex', gap: 6 }}>
            <button className="wf-btn focus" style={{ flex: 1, minHeight: 28, fontSize: 12, padding: '2px 6px', background: '#222', color: '#fff', borderColor: '#fff' }}>Info</button>
            <button className="wf-btn" style={{ flex: 1, minHeight: 28, fontSize: 12, padding: '2px 6px', background: 'transparent', color: '#888', borderColor: '#444' }}>Debug</button>
            <button className="wf-btn" style={{ flex: 1, minHeight: 28, fontSize: 12, padding: '2px 6px', background: 'transparent', color: '#888', borderColor: '#444' }}>Sources</button>
          </div>
          <div style={{ padding: 12, fontFamily: 'var(--mono)', fontSize: 12, lineHeight: 1.6 }}>
            <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 18, color: '#fff', marginBottom: 6 }}>Metadata</div>
            <div><span style={{ color: '#888' }}>Title</span><br />LA BALADA DE AURONPLAY</div>
            <div style={{ marginTop: 6 }}><span style={{ color: '#888' }}>Author</span><br />Lucas Requena</div>
            <div style={{ marginTop: 6 }}><span style={{ color: '#888' }}>Duration</span> 04:04</div>
            <div style={{ marginTop: 6 }}><span style={{ color: '#888' }}>Published</span> 2021-01-22</div>
            <div style={{ marginTop: 12, paddingTop: 10, borderTop: '1px dashed #444' }}>
              <div style={{ color: 'var(--c-cyan)' }}>Engine: FFMediaPlayer</div>
              <div style={{ color: 'var(--c-cyan)' }}>Size: 1920×1080</div>
              <div style={{ color: 'var(--c-play)' }}>● PLAYING</div>
            </div>
          </div>
        </aside>
      </div>
      <Footer><Key>Tab</Key> Cycle panel · <Key>D</Key> Toggle rail · <Key>SPACE</Key> Play/Pause</Footer>
    </div>
  );
}

// V3 — Theater mode: video centered, info as bottom-sheet card
function PlayerV3() {
  return (
    <div className="wf" data-density="cozy" style={{ background: '#0a0a0a' }}>
      <Titlebar />
      <div style={{ flex: 1, position: 'relative', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div style={{ flex: 1, background: '#222', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#666', fontFamily: 'var(--mono)' }} className="crt">
          [ video — letterboxed ]
          <div style={{ position: 'absolute', top: 10, left: 10, display: 'flex', gap: 4 }}>
            <span className="neon-tag">LIVE: NO</span>
            <span className="neon-tag" style={{ borderColor: 'var(--c-cyan)', color: 'var(--c-cyan)' }}>1080p</span>
          </div>
        </div>

        {/* Bottom sheet */}
        <div style={{ background: '#1a1a1a', borderTop: '2px solid var(--c-neon)', padding: 12, color: '#eee', display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, alignItems: 'center' }}>
          <div>
            <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 19, color: '#fff' }}>LA BALADA DE AURONPLAY</div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: '#aaa', marginTop: 2 }}>Lucas Requena · 04:04 · 2021-01-22 · YouTube</div>
            {/* Transport */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
              <button className="wf-btn green" style={{ minHeight: 32, padding: '2px 10px' }}>▶</button>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>0:01</span>
              <div style={{ flex: 1, height: 6, background: '#333', position: 'relative' }}>
                <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '5%', background: 'var(--c-neon)' }} />
              </div>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>4:04</span>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontFamily: 'var(--mono)', fontSize: 11, color: '#888', textAlign: 'right' }}>
            <span>🔊 100% · 1.0×</span>
            <span style={{ color: 'var(--c-play)' }}>● PLAYING</span>
            <button className="wf-btn" style={{ minHeight: 22, fontSize: 11, padding: '2px 6px', background: 'transparent', color: '#aaa', borderColor: '#555' }}>show debug ▾</button>
          </div>
        </div>
      </div>
      <Footer><Key>I</Key> Toggle info sheet · <Key>F</Key> Fullscreen</Footer>
    </div>
  );
}

// V4 — Synthwave HUD: video + neon overlay framing, zero chrome on idle
function PlayerV4() {
  return (
    <div className="wf" data-density="cozy" style={{ background: '#08101e' }}>
      <Titlebar />
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <div className="crt" style={{ position: 'absolute', inset: 16, border: '2px solid #6ea8ff', boxShadow: '0 0 24px rgba(110,168,255,0.4), inset 0 0 24px rgba(110,168,255,0.15)', background: '#0e1422', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#6ea8ffaa', fontFamily: 'var(--mono)' }}>
          [ video frame ]
        </div>

        {/* Corner brackets */}
        {[
          { top: 16, left: 16, b: ['top','left'] },
          { top: 16, right: 16, b: ['top','right'] },
          { bottom: 16, left: 16, b: ['bottom','left'] },
          { bottom: 16, right: 16, b: ['bottom','right'] },
        ].map((c, i) => (
          <div key={i} style={{
            position: 'absolute', width: 28, height: 28,
            ...c,
            borderTop: c.b.includes('top') ? '3px solid #2dd4ff' : 'none',
            borderBottom: c.b.includes('bottom') ? '3px solid #2dd4ff' : 'none',
            borderLeft: c.b.includes('left') ? '3px solid #2dd4ff' : 'none',
            borderRight: c.b.includes('right') ? '3px solid #2dd4ff' : 'none',
          }} />
        ))}

        {/* Top neon strip */}
        <div style={{ position: 'absolute', top: 26, left: 60, right: 60, fontFamily: 'var(--mono)', fontSize: 13, color: '#2dd4ff', display: 'flex', justifyContent: 'space-between', textShadow: '0 0 6px #2dd4ff88' }}>
          <span>► LA BALADA DE AURONPLAY · LUCAS REQUENA</span>
          <span>FFMP · 1920×1080 · ●REC</span>
        </div>

        {/* Bottom transport — neon */}
        <div style={{ position: 'absolute', bottom: 30, left: 60, right: 60, padding: 10, border: '1.5px solid #6ea8ff', background: 'rgba(13,10,24,0.85)', color: '#fff', fontFamily: 'var(--mono)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 10, boxShadow: '0 0 16px rgba(110,168,255,0.4)' }}>
          <span style={{ color: '#4ade80' }}>▶</span>
          <span>00:01</span>
          <div style={{ flex: 1, height: 4, background: '#1d2740', position: 'relative' }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '8%', background: 'linear-gradient(90deg, #2dd4ff, #6ea8ff)', boxShadow: '0 0 8px #6ea8ff' }} />
          </div>
          <span>04:04</span>
          <span style={{ color: '#6ea8ff' }}>1080p</span>
          <span>🔊 100</span>
        </div>
      </div>
      <Footer><Key>SPACE</Key> Play · <Key>H</Key> HUD · <Key>ESC</Key> Exit</Footer>
    </div>
  );
}

Object.assign(window, { PlayerV1, PlayerV2, PlayerV3, PlayerV4 });

/* global React, Titlebar, Footer, Key, Logo, PixelIcon, Annotation, VarHead */
// Main menu — 4 variations exploring layout, density, and visual hierarchy.

// V1 — Cleaned-up version of current: same structure, better grouping, mouse hover states.
function MainMenuV1() {
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '14px 18px', borderBottom: '2px solid var(--ink)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Logo size="md" />
        <div style={{ display: 'flex', gap: 6 }}>
          <span className="neon-tag">v2.0.0</span>
          <span className="neon-tag" style={{ borderColor: 'var(--c-info)', color: 'var(--c-info)' }}>standalone</span>
        </div>
      </div>

      <div style={{ padding: '16px 18px', flex: 1 }}>
        <div className="wf-section-label">Actions</div>
        <div style={{ display: 'flex', gap: 12, marginBottom: 22 }}>
          <button className="wf-btn green focus" style={{ flex: '1 1 0', minHeight: 86 }}>
            <PixelIcon shape="play" color="var(--c-play)" size={20} />
            <span style={{ fontSize: 22 }}>Play</span>
            <span className="wf-note" style={{ fontSize: 12 }}>open URL or file</span>
          </button>
          <button className="wf-btn" style={{ flex: '1 1 0', minHeight: 86 }}>
            <PixelIcon shape="upload" size={18} />
            <span>Upload Logs</span>
          </button>
          <button className="wf-btn blue" style={{ flex: '1 1 0', minHeight: 86 }}>
            <PixelIcon shape="broom" color="var(--c-info)" size={18} />
            <span>Cleanup</span>
          </button>
          <button className="wf-btn red" style={{ flex: '1 1 0', minHeight: 86 }}>
            <PixelIcon shape="x" color="var(--c-danger)" size={16} />
            <span>Exit</span>
          </button>
        </div>

        <div className="wf-section-label">Media Tests</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10 }}>
          {['Platforms','WEBP lossy','WEBP lossless','GIF format','PNG format','Video format'].map(t => (
            <button key={t} className="wf-btn" style={{ minHeight: 70, fontSize: 14 }}>
              <PixelIcon shape="folder" size={16} />
              <span>{t}</span>
            </button>
          ))}
        </div>

        <Annotation arrow="up" style={{ marginTop: 10 }}>
          Same skeleton, but consistent hierarchy + hover/focus rings + tooltips.
        </Annotation>
      </div>

      <Footer>
        <Key>↑↓←→</Key> Navigate
        <Key>↵</Key> Select
        <Key>ESC</Key> Exit
        <span style={{ marginLeft: 'auto', opacity: 0.6 }}>mouse OK</span>
      </Footer>
    </div>
  );
}

// V2 — Sidebar nav + content grid; thumbnails replace plain folder buttons.
function MainMenuV2() {
  const tests = [
    { name: 'Platforms', n: 4, color: 'var(--c-info)' },
    { name: 'WEBP lossy', n: 9, color: 'var(--c-neon)' },
    { name: 'WEBP lossless', n: 6, color: 'var(--c-neon)' },
    { name: 'GIF', n: 12, color: 'var(--c-warn)' },
    { name: 'PNG', n: 8, color: 'var(--c-cyan)' },
    { name: 'Video', n: 5, color: 'var(--c-play)' },
  ];
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        {/* Sidebar */}
        <aside style={{ width: 200, borderRight: '2px solid var(--ink)', background: 'var(--paper-warm)', padding: '14px 12px', display: 'flex', flexDirection: 'column', gap: 6 }}>
          <Logo size="sm" />
          <div style={{ height: 12 }} />
          <div className="wf-note" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, marginTop: 6 }}>Actions</div>
          <button className="wf-btn green focus" style={{ flexDirection: 'row', justifyContent: 'flex-start', minHeight: 38, fontSize: 16 }}>
            <PixelIcon shape="play" color="var(--c-play)" size={14} /> Play
          </button>
          <button className="wf-btn" style={{ flexDirection: 'row', justifyContent: 'flex-start', minHeight: 36, fontSize: 14 }}>
            <PixelIcon shape="upload" size={12} /> Upload Logs
          </button>
          <button className="wf-btn blue" style={{ flexDirection: 'row', justifyContent: 'flex-start', minHeight: 36, fontSize: 14 }}>
            <PixelIcon shape="broom" color="var(--c-info)" size={12} /> Cleanup
          </button>
          <button className="wf-btn" style={{ flexDirection: 'row', justifyContent: 'flex-start', minHeight: 36, fontSize: 14 }}>
            <PixelIcon shape="settings" size={12} /> Settings
          </button>
          <div style={{ flex: 1 }} />
          <button className="wf-btn red" style={{ flexDirection: 'row', justifyContent: 'flex-start', minHeight: 34, fontSize: 14 }}>
            <PixelIcon shape="x" color="var(--c-danger)" size={12} /> Exit
          </button>
        </aside>

        {/* Content */}
        <section style={{ flex: 1, padding: '14px 18px', minWidth: 0, overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
            <div className="wf-section-label" style={{ margin: 0 }}>Media Tests</div>
            <div className="wf-note" style={{ fontSize: 13 }}>44 samples · 6 categories</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {tests.map(t => (
              <div key={t.name} className="wf-box" style={{ padding: 10, display: 'flex', gap: 10, alignItems: 'center', minHeight: 72 }}>
                <div style={{ width: 56, height: 56, border: '2px solid var(--ink)', background: 'repeating-linear-gradient(45deg, var(--paper-warm), var(--paper-warm) 4px, var(--paper) 4px, var(--paper) 8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-soft)' }}>
                  preview
                </div>
                <div>
                  <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 19, color: t.color }}>{t.name}</div>
                  <div className="wf-note" style={{ fontSize: 12 }}>{t.n} items</div>
                </div>
              </div>
            ))}
          </div>
          <Annotation arrow="up" style={{ marginTop: 12 }}>
            Sidebar = persistent actions. Cards w/ live preview thumb on the left.
          </Annotation>
        </section>
      </div>

      <Footer>
        <Key>Tab</Key> Switch panel
        <Key>↑↓</Key> Navigate
        <Key>↵</Key> Open
      </Footer>
    </div>
  );
}

// V3 — Hero "Play" + chips for tests. Most space to primary action.
function MainMenuV3() {
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}>
        <Logo size="md" />
      </div>
      <div style={{ flex: 1, padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {/* Hero */}
        <div className="wf-box thick" style={{ padding: 18, display: 'flex', gap: 16, alignItems: 'center', borderColor: 'var(--c-play)', background: 'linear-gradient(135deg, var(--paper) 60%, rgba(47,138,74,0.08))' }}>
          <button className="wf-btn green focus" style={{ width: 110, height: 100, flexShrink: 0 }}>
            <PixelIcon shape="play" color="var(--c-play)" size={32} />
            <span style={{ fontSize: 24 }}>Play</span>
          </button>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 24 }}>Open any media</div>
            <div className="wf-note" style={{ fontSize: 14, marginTop: 4 }}>
              Paste a URL or drop a file — YouTube, Twitch, GIF, WEBP, PNG, MP4...
            </div>
            <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              <span className="neon-tag">URL</span>
              <span className="neon-tag" style={{ borderColor: 'var(--c-cyan)', color: 'var(--c-cyan)' }}>FILE</span>
              <span className="neon-tag" style={{ borderColor: 'var(--c-warn)', color: 'var(--c-warn)' }}>CLIPBOARD</span>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <button className="wf-btn" style={{ minHeight: 36, fontSize: 13, padding: '4px 10px' }}><PixelIcon shape="upload" size={12} /> Upload Logs</button>
            <button className="wf-btn blue" style={{ minHeight: 36, fontSize: 13, padding: '4px 10px' }}><PixelIcon shape="broom" color="var(--c-info)" size={12} /> Cleanup</button>
            <button className="wf-btn red" style={{ minHeight: 36, fontSize: 13, padding: '4px 10px' }}><PixelIcon shape="x" color="var(--c-danger)" size={12} /> Exit</button>
          </div>
        </div>

        {/* Tests as chips */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8 }}>
            <div className="wf-section-label" style={{ margin: 0 }}>Quick test bench</div>
            <span className="wf-note" style={{ fontSize: 13 }}>tap a format →</span>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {[
              ['Platforms','var(--c-info)'],
              ['WEBP lossy','var(--c-neon)'],
              ['WEBP lossless','var(--c-neon)'],
              ['GIF','var(--c-warn)'],
              ['PNG','var(--c-cyan)'],
              ['Video','var(--c-play)'],
              ['Audio','var(--ink-soft)'],
              ['Streaming','var(--c-info)'],
            ].map(([t,c]) => (
              <button key={t} className="wf-btn" style={{ minHeight: 44, padding: '6px 14px', flexDirection: 'row', gap: 8, fontSize: 15, borderColor: c, color: c }}>
                <PixelIcon shape="folder" color={c} size={14} /> {t}
              </button>
            ))}
          </div>
        </div>
        <Annotation arrow="up">Primary action gets ~50% of fold. Tests demoted to secondary.</Annotation>
      </div>
      <Footer>
        <Key>Space</Key> Quick play
        <Key>Ctrl+V</Key> Paste URL
        <Key>ESC</Key> Exit
      </Footer>
    </div>
  );
}

// V4 — Synthwave/CRT terminal vibe: grid background, neon, no titlebar.
function MainMenuV4() {
  return (
    <div className="wf" data-density="cozy" style={{
      background: '#08101e',
      color: '#e8e6f5',
      backgroundImage: `
        linear-gradient(rgba(110,168,255,0.08) 1px, transparent 1px),
        linear-gradient(90deg, rgba(110,168,255,0.08) 1px, transparent 1px),
        radial-gradient(circle at 50% 120%, rgba(110,168,255,0.25), transparent 60%)
      `,
      backgroundSize: '32px 32px, 32px 32px, 100% 100%'
    }}>
      <div style={{ height: 28, background: '#0e1422', color: '#6ea8ff', fontFamily: 'var(--mono)', fontSize: 14, display: 'flex', alignItems: 'center', padding: '0 12px', borderBottom: '1px solid #6ea8ff' }}>
        ◆ WATERMEDIA :: STANDALONE :: v2.0.0
        <span style={{ marginLeft: 'auto', opacity: 0.7 }}>OpenGL · ready</span>
      </div>

      <div style={{ padding: '20px 24px', display: 'flex', alignItems: 'center', gap: 18 }}>
        <div style={{ width: 60, height: 60, border: '2px solid #6ea8ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--mono)', fontSize: 10, color: '#6ea8ff' }}>DUCK</div>
        <div>
          <div style={{ fontFamily: 'var(--pixel)', fontSize: 28, color: '#2dd4ff', textShadow: '0 0 12px rgba(45,212,255,0.6)' }}>WATERMEDIA</div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 13, color: '#6ea8ff', letterSpacing: 2, marginTop: 4 }}>// MULTIMEDIA · FOR · MINECRAFT //</div>
        </div>
      </div>

      <div style={{ flex: 1, padding: '0 24px 16px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Actions column */}
        <div>
          <div style={{ fontFamily: 'var(--mono)', color: '#6ea8ff', fontSize: 13, letterSpacing: 2, marginBottom: 10 }}>▌ ACTIONS</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              ['▶','Play','#4ade80', true],
              ['↑','Upload Logs','#2dd4ff', false],
              ['✻','Cleanup','#6ea8ff', false],
              ['×','Exit','#ff5572', false],
            ].map(([ico, name, color, focus]) => (
              <div key={name} style={{
                border: `1.5px solid ${color}`,
                background: focus ? `${color}1a` : 'transparent',
                padding: '10px 14px',
                display: 'flex', alignItems: 'center', gap: 14,
                fontFamily: 'var(--mono)', fontSize: 18,
                color,
                boxShadow: focus ? `0 0 12px ${color}66, inset 0 0 12px ${color}22` : 'none',
              }}>
                <span style={{ fontSize: 20 }}>{ico}</span>
                <span>{name}</span>
                {focus && <span style={{ marginLeft: 'auto', fontSize: 12, opacity: 0.7 }}>[ENTER]</span>}
              </div>
            ))}
          </div>
        </div>
        {/* Tests column */}
        <div>
          <div style={{ fontFamily: 'var(--mono)', color: '#2dd4ff', fontSize: 13, letterSpacing: 2, marginBottom: 10 }}>▌ TESTS</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            {['Platforms','WEBP lossy','WEBP lossless','GIF','PNG','Video'].map(t => (
              <div key={t} style={{ border: '1.5px solid #2dd4ff44', padding: '8px 10px', fontFamily: 'var(--mono)', fontSize: 14, color: '#2dd4ff', display: 'flex', alignItems: 'center', gap: 8 }}>
                <span>▣</span> {t}
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12, fontFamily: 'var(--mono)', fontSize: 11, color: '#fff8', lineHeight: 1.6 }}>
            <div>{'>'} idle. ready for input.</div>
            <div>{'>'} backend: ffmpeg + opengl</div>
            <div>{'>'} cache: 412 MB / 2 GB</div>
          </div>
        </div>
      </div>

      <div style={{ borderTop: '1px solid #6ea8ff', padding: '6px 14px', fontFamily: 'var(--mono)', fontSize: 13, color: '#6ea8ff', display: 'flex', gap: 16 }}>
        <span>[↵] EXEC</span><span>[↑↓] NAV</span><span>[ESC] BAIL</span>
        <span style={{ marginLeft: 'auto' }}>● online</span>
      </div>
    </div>
  );
}

Object.assign(window, { MainMenuV1, MainMenuV2, MainMenuV3, MainMenuV4 });

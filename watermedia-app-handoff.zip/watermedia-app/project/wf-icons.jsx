/* global React, PixelIcon, Annotation */

// Iconography exploration — pixel + linear hybrid system
function IconSystem() {
  const pixelIcons = ['play','pause','folder','upload','broom','x','settings'];
  return (
    <div className="wf" data-density="cozy">
      <div style={{ padding: '14px 18px', borderBottom: '2px solid var(--ink)' }}>
        <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 22 }}>Icon System — pixel × linear hybrid</div>
        <div className="wf-note" style={{ fontSize: 13 }}>pixel for actions/status (Minecraft DNA) · linear stroke for utility/settings</div>
      </div>
      <div style={{ flex: 1, padding: 18, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
        <div>
          <div className="wf-section-label" style={{ fontSize: 17 }}>Pixel set · 16×16</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {pixelIcons.map(s => (
              <div key={s} className="wf-box" style={{ padding: 10, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                <PixelIcon shape={s} size={24} />
                <span style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{s}</span>
              </div>
            ))}
          </div>
          <Annotation arrow="up" style={{ marginTop: 8 }}>Use for: play/pause/stop, status, folders, exit</Annotation>
        </div>
        <div>
          <div className="wf-section-label" style={{ fontSize: 17 }}>Linear stroke · 1.5px</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {[
              ['gear', <circle cx="12" cy="12" r="3" /> ],
              ['volume', <path d="M3 9v6h4l5 4V5L7 9H3z" />],
              ['info', <><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="17"/><circle cx="12" cy="8" r="0.5" fill="currentColor"/></>],
              ['warn', <><path d="M12 3 L22 21 L2 21 Z"/><line x1="12" y1="10" x2="12" y2="15"/></>],
              ['link', <><path d="M9 15l6-6"/><path d="M14 6l3 3"/><path d="M7 14l3 3"/></>],
              ['eye', <><path d="M2 12 C5 6, 19 6, 22 12 C19 18, 5 18, 2 12 Z"/><circle cx="12" cy="12" r="3"/></>],
              ['search', <><circle cx="11" cy="11" r="6"/><line x1="20" y1="20" x2="16" y2="16"/></>],
              ['cache', <><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6 v12 a8 3 0 0 0 16 0 V6"/></>],
            ].map(([n, body]) => (
              <div key={n} className="wf-box" style={{ padding: 10, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">{body}</svg>
                <span style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{n}</span>
              </div>
            ))}
          </div>
          <Annotation arrow="up" style={{ marginTop: 8 }}>Use for: settings, info, search, abstract concepts</Annotation>
        </div>
      </div>
      <div style={{ padding: 14, borderTop: '2px solid var(--ink)', display: 'flex', gap: 18, fontFamily: 'var(--mono)', fontSize: 12 }}>
        <span className="swatch" style={{ color: 'var(--c-play)' }}>play / OK</span>
        <span className="swatch" style={{ color: 'var(--c-info)' }}>info / focus</span>
        <span className="swatch" style={{ color: 'var(--c-warn)' }}>warning</span>
        <span className="swatch" style={{ color: 'var(--c-danger)' }}>danger / exit</span>
        <span className="swatch" style={{ color: 'var(--c-neon)' }}>accent (synthwave)</span>
        <span className="swatch" style={{ color: 'var(--c-cyan)' }}>media tag</span>
      </div>
    </div>
  );
}

Object.assign(window, { IconSystem });

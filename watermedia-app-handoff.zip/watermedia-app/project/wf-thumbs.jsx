/* global React, Titlebar, Footer, Key, Logo, PixelIcon, Annotation */
// Thumbnails grid — 4 variations.

function Thumb({ name, status = 'ok', large = false, type = 'img' }) {
  const h = large ? 140 : 90;
  return (
    <div className="wf-thumb" style={{ minHeight: h, padding: 0, position: 'relative' }}>
      <div className="status" title={status} style={{ background: status === 'ok' ? 'var(--c-play)' : status === 'err' ? 'var(--c-danger)' : 'var(--c-warn)' }} />
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-soft)', fontFamily: 'var(--mono)', fontSize: 11 }}>
        {status === 'load' ? '⟳ loading…' : status === 'err' ? '✕ error' : `[${type}]`}
      </div>
      <div className="label" style={{ width: '100%', display: 'flex', justifyContent: 'space-between' }}>
        <span>{name}</span>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 10, opacity: 0.7 }}>{type}</span>
      </div>
    </div>
  );
}

// V1 — Bigger thumbs, 4 cols, hover preview, status pip
function ThumbsV1() {
  const items = [
    ['HEX','ok','webp'],['RGB','ok','webp'],['TV TEST','ok','webp'],['ANIMATED','load','webp'],
    ['WEBP #1','ok','webp'],['WEBP #2','err','webp'],['WEBP #3','ok','webp'],['WEBP #4','ok','webp'],
  ];
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <Logo size="sm" />
        <div className="wf-section-label" style={{ margin: 0, fontSize: 18 }}>Select Media — WEBP lossy</div>
      </div>
      <div style={{ flex: 1, padding: 14, overflow: 'auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {items.map(([n,s,t], i) => (
            <div key={i} style={{ position: 'relative' }}>
              <Thumb name={n} status={s} type={t} large />
              {i === 0 && <div style={{ position:'absolute', inset:-4, border:'3px solid var(--c-info)', pointerEvents:'none' }} />}
            </div>
          ))}
        </div>
        <Annotation arrow="up" style={{ marginTop: 10 }}>4 cols, ~140px tall · status dot · hover = bigger preview popover</Annotation>
      </div>
      <Footer><Key>↵</Key> Open · <Key>Space</Key> Preview · <Key>ESC</Key> Back</Footer>
    </div>
  );
}

// V2 — List view with inline preview pane on right
function ThumbsV2() {
  const items = [['HEX','ok'],['RGB','ok'],['TV TEST','ok'],['ANIMATED','load'],['WEBP #1','ok'],['WEBP #2','err'],['WEBP #3','ok']];
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}><Logo size="sm" /></div>
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <div style={{ width: 320, borderRight: '2px solid var(--ink)', overflow: 'auto' }}>
          {items.map(([n,s],i) => (
            <div key={i} style={{ padding: '8px 12px', display: 'flex', gap: 10, alignItems: 'center', borderBottom: '1px dashed var(--ink-faint)', background: i===0 ? 'rgba(110,168,255,0.15)' : 'transparent' }}>
              <div style={{ width: 50, height: 36, border: '1.5px solid var(--ink)', background: 'repeating-linear-gradient(45deg, var(--paper-warm), var(--paper-warm) 4px, var(--paper) 4px, var(--paper) 8px)' }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--hand-bold)', fontSize: 16 }}>{n}</div>
                <div className="wf-note" style={{ fontSize: 11 }}>https://files.catbox.moe/...webp</div>
              </div>
              <span style={{ width: 10, height: 10, borderRadius: '50%', background: s==='ok'?'var(--c-play)':s==='err'?'var(--c-danger)':'var(--c-warn)' }} />
            </div>
          ))}
        </div>
        <div style={{ flex: 1, padding: 18, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="wf-thumb" style={{ flex: 1, minHeight: 200 }}>
            <div style={{ flex: 1, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--mono)', color:'var(--ink-soft)' }}>[ large preview ]</div>
            <div className="label">HEX · 512×512 · 24 KB · WEBP lossy</div>
          </div>
          <button className="wf-btn green focus" style={{ alignSelf: 'flex-start' }}><PixelIcon shape="play" color="var(--c-play)" size={16} /> Play this</button>
          <Annotation arrow="left">List + preview = clearer URL/metadata + faster scanning</Annotation>
        </div>
      </div>
      <Footer><Key>↑↓</Key> Browse · <Key>↵</Key> Play · <Key>/</Key> Search</Footer>
    </div>
  );
}

// V3 — Mosaic / pinterest-ish staggered, focus on imagery
function ThumbsV3() {
  const items = [['HEX',2],['RGB',1],['TV',1],['ANIMATED',2],['#1',1],['#2',1],['#3',2],['#4',1]];
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '10px 18px', borderBottom:'2px solid var(--ink)', display:'flex', justifyContent:'space-between' }}>
        <Logo size="sm" />
        <div style={{ display: 'flex', gap: 6 }}>
          <input className="wf-box" placeholder="search…" style={{ padding: '4px 10px', fontFamily: 'var(--mono)' }} />
          <button className="wf-btn" style={{ minHeight: 30, fontSize: 12, padding: '2px 8px' }}>filters ▾</button>
        </div>
      </div>
      <div style={{ flex: 1, padding: 14, overflow: 'auto' }}>
        <div style={{ columnCount: 4, columnGap: 10 }}>
          {items.map(([n,h],i) => (
            <div key={i} style={{ breakInside: 'avoid', marginBottom: 10 }}>
              <Thumb name={n} status="ok" large />
              {h === 2 && <div style={{ height: 40 }} />}
            </div>
          ))}
        </div>
        <Annotation arrow="up" style={{ marginTop: 8 }}>Masonry layout · breath of an art gallery · status badges still on</Annotation>
      </div>
      <Footer><Key>↵</Key> Open</Footer>
    </div>
  );
}

// V4 — Synthwave grid w/ neon selection
function ThumbsV4() {
  const items = ['HEX','RGB','TV TEST','ANIMATED','WEBP #1','WEBP #2','WEBP #3','WEBP #4','WEBP #5'];
  return (
    <div className="wf" data-density="cozy" style={{ background: '#08101e', color: '#e8e6f5' }}>
      <div style={{ height: 28, background: '#0e1422', color: '#6ea8ff', fontFamily: 'var(--mono)', fontSize: 13, padding: '0 12px', display: 'flex', alignItems: 'center', borderBottom: '1px solid #6ea8ff' }}>
        ◆ WATERMEDIA :: SELECT MEDIA :: WEBP/lossy
      </div>
      <div style={{ flex: 1, padding: 16, overflow: 'auto' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap: 14 }}>
          {items.map((n,i)=>(
            <div key={i} style={{
              border: i===2 ? '2px solid #2dd4ff' : '1.5px solid #6ea8ff66',
              boxShadow: i===2 ? '0 0 16px rgba(45,212,255,0.6)' : 'none',
              minHeight: 130, position: 'relative', padding: 8,
              display:'flex', flexDirection:'column', justifyContent:'space-between',
              background: 'rgba(110,168,255,0.05)'
            }}>
              <span style={{ position:'absolute', top:4, right:4, color: '#4ade80', fontFamily:'var(--mono)', fontSize: 10 }}>● OK</span>
              <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', color:'#6ea8ff', fontFamily:'var(--mono)', fontSize: 11 }}>[ webp ]</div>
              <div style={{ fontFamily: 'var(--pixel)', fontSize: 10, color: '#fff', letterSpacing: 1 }}>{n}</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: '#aaa' }}>files.catbox.moe</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ borderTop: '1px solid #6ea8ff', padding: '6px 14px', fontFamily: 'var(--mono)', fontSize: 12, color: '#6ea8ff' }}>
        [↵] OPEN · [/] FILTER · [ESC] BACK
      </div>
    </div>
  );
}

Object.assign(window, { ThumbsV1, ThumbsV2, ThumbsV3, ThumbsV4 });

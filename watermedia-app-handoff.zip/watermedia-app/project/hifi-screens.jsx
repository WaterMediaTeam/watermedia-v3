/* global React, Titlebar, Footer, K, PixIcon, LineIcon, Banner, VideoSurface */
// Hi-fi: Media selector (V2 list+preview using V1 mini-TV frames),
//        Sources/Qualities (V1 two-pane synthwave),
//        Loading (duck icon, no emoji),
//        Settings (sidebar synthwave),
//        Inline disabled+tooltip dialog.

const { useState: useS } = React;

// =================================================================
// MEDIA SELECTOR — list of mini-TV thumbs + larger preview
// =================================================================
function MediaSelectorScreen({ density = 'cozy' }) {
  const items = [
    { name: 'HEX',     status: 'ok',   url: 'files.catbox.moe/hex.webp',         size: '512×512',  bytes: '24 KB' },
    { name: 'RGB',     status: 'ok',   url: 'gstatic.com/rgb.webp',              size: '256×256',  bytes: '12 KB' },
    { name: 'TV TEST', status: 'ok',   url: 'gstatic.com/tvtest.webp',           size: '720×480',  bytes: '48 KB' },
    { name: 'ANIMATED',status: 'load', url: 'mathiasbynens.be/animated.webp',    size: '400×400',  bytes: '— KB' },
    { name: 'WEBP #1', status: 'ok',   url: 'gstatic.com/webp1.webp',            size: '512×512',  bytes: '32 KB' },
    { name: 'WEBP #2', status: 'err',  url: 'gstatic.com/webp2.webp',            size: '— ',      bytes: 'ERR 404' },
    { name: 'WEBP #3', status: 'ok',   url: 'gstatic.com/webp3.webp',            size: '640×480',  bytes: '56 KB' },
    { name: 'WEBP #4', status: 'ok',   url: 'gstatic.com/webp4.webp',            size: '512×512',  bytes: '28 KB' },
  ];
  const [sel, setSel] = useS(0);
  const cur = items[sel];

  return (
    <div className="app" data-density={density}>
      <Titlebar title="WATERMeDIA — Select media · WEBP/lossy" />

      <Header
        name="Select media"
        sub="webp · lossy"
        right={<span className="tag">{items.length} items</span>}
      />

      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* LIST (left) */}
        <aside style={{ width: 360, borderRight: '1px solid var(--stroke-bright)', display: 'flex', flexDirection: 'column', minHeight: 0, background: 'rgba(10,15,36,0.4)' }}>
          <div style={{ padding: '8px 12px', borderBottom: '1px dashed var(--stroke)', display: 'flex', gap: 6, alignItems: 'center' }}>
            <LineIcon name="search" size={12} />
            <input
              placeholder="filter…"
              style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'var(--text)', fontFamily: 'var(--mono)', fontSize: 12 }}
            />
            <span className="tag" style={{ fontSize: 9 }}>/</span>
          </div>
          <div className="sec-head" style={{ padding: '10px 14px 4px', margin: 0 }}>
            WEBP / lossy <span className="count">{items.length} items</span>
          </div>
          <div style={{ flex: 1, overflow: 'auto', padding: '0 8px 8px' }}>
            {items.map((it, i) => (
              <div
                key={it.name}
                onClick={() => setSel(i)}
                style={{
                  padding: 8,
                  display: 'flex', gap: 10, alignItems: 'center',
                  cursor: 'pointer',
                  border: '1px solid ' + (i === sel ? 'var(--neon)' : 'transparent'),
                  background: i === sel ? 'rgba(110,168,255,0.10)' : 'transparent',
                  boxShadow: i === sel ? '0 0 12px var(--glow-soft)' : 'none',
                  marginBottom: 4,
                }}
              >
                {/* Mini TV thumbnail */}
                <div className="tv" style={{ width: 64, height: 44, padding: 3, flexShrink: 0 }}>
                  <span className="corner bl" /><span className="corner br" />
                  <div className="screen" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, color: 'var(--text-faint)', fontFamily: 'var(--mono)' }}>
                    {it.status === 'load' ? '⟳' : it.status === 'err' ? '✕' : 'webp'}
                  </div>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 13, color: i === sel ? 'var(--neon-1)' : 'var(--text)', textTransform: 'uppercase', letterSpacing: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {it.name}
                  </div>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-faint)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {it.url}
                  </div>
                </div>
                <span className={'pip ' + it.status} title={it.status} />
              </div>
            ))}
          </div>
        </aside>

        {/* PREVIEW (right) — no sec-head, index moved into metadata box */}
        <section style={{ flex: 1, padding: 18, display: 'flex', flexDirection: 'column', gap: 14, minWidth: 0 }}>
          {/* Big TV frame */}
          <div className="tv is-focus" style={{ flex: 1, padding: 10, minHeight: 0 }}>
            <span className="corner bl" /><span className="corner br" />
            <div className="screen" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
              <VideoSurface dim={cur.status !== 'ok'}>
                <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 8, color: 'var(--text-soft)', fontFamily: 'var(--mono)', textAlign: 'center' }}>
                  {cur.status === 'load' && (<><div className="duck-loader" style={{ width: 48, height: 48, background: "url('assets/duck-icon.png') center/contain no-repeat", imageRendering: 'pixelated' }} /><div>loading…</div></>)}
                  {cur.status === 'err'  && (<><LineIcon name="warn" size={28} /><div style={{ color: 'var(--red)' }}>{cur.bytes}</div></>)}
                  {cur.status === 'ok'   && <div style={{ fontSize: 13, letterSpacing: 2 }}>[ {cur.name} · webp lossy ]</div>}
                </div>
              </VideoSurface>
            </div>
          </div>

          {/* Metadata + actions — no index/count, just info + Play */}
          <div className="panel anchored" style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 14, alignItems: 'center' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontFamily: 'var(--mono)', fontSize: 11, lineHeight: 1.6, minWidth: 0 }}>
              <div style={{ fontSize: 14, color: 'var(--neon-1)', letterSpacing: 1, textTransform: 'uppercase', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{cur.name}</div>
              <div style={{ color: 'var(--text-soft)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{cur.url}</div>
              <div style={{ display: 'flex', gap: 8, color: 'var(--text-faint)', alignItems: 'center' }}>
                <span>{cur.size}</span>·<span>{cur.bytes}</span>·<span className={'pip ' + cur.status} style={{ marginRight: 4 }} />
                <span style={{ color: cur.status === 'ok' ? 'var(--green)' : cur.status === 'err' ? 'var(--red)' : 'var(--neon)' }}>
                  {cur.status === 'ok' ? 'READY' : cur.status === 'err' ? 'ERROR' : 'LOADING'}
                </span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn" disabled={cur.status !== 'ok'}>
                <LineIcon name="link" size={12} /> Copy URL
              </button>
              <button className="btn green focus" disabled={cur.status !== 'ok'}>
                <PixIcon name="play" size={12} color="var(--green)" /> Play
              </button>
            </div>
          </div>
        </section>
      </div>

      <Footer
        left={<>
          <span><K>↑↓</K> Browse</span>
          <span><K>↵</K> Play</span>
          <span><K>/</K> Filter</span>
          <span><K>ESC</K> Back</span>
        </>}
        right={<BackendStrip />}
      />
    </div>
  );
}

// =================================================================
// SOURCES / QUALITIES — modal over a paused player
// =================================================================
function SourcesScreen({ density = 'cozy' }) {
  const [src, setSrc] = useS(0);
  const [q, setQ] = useS(2);
  const sources = [
    { name: 'LA BALADA DE AURONPLAY', kind: 'VIDEO', dur: '04:04', q: 8 },
  ];
  const qualities = [
    { name: 'Q144P',  label: '144p',  bps: '60 KB/s',  badge: 'low' },
    { name: 'LOWER',  label: '360p',  bps: '220 KB/s', badge: 'med' },
    { name: 'MEDIUM', label: '720p',  bps: '620 KB/s', badge: 'HD' },
    { name: 'HIGH',   label: '1080p', bps: '1.2 MB/s', badge: 'FHD' },
  ];

  return (
    <div className="app" data-density={density}>
      <Titlebar title="WATERMeDIA — Now Playing" />
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <VideoSurface dim />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-faint)', fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 2 }}>
          [ video paused ]
        </div>

        {/* Modal */}
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(6,9,26,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="tv is-focus" style={{ width: 600, padding: 0 }}>
            <span className="corner bl" /><span className="corner br" />
            <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', background: 'var(--bg-1)' }}>
              {/* Sources */}
              <div style={{ padding: 14, borderRight: '1px solid var(--stroke-bright)' }}>
                <div className="panel-head">Sources</div>
                {sources.map((s, i) => (
                  <div key={s.name}
                       onClick={() => setSrc(i)}
                       style={{
                         padding: 10, marginBottom: 6, cursor: 'pointer',
                         border: '1px solid ' + (i === src ? 'var(--neon)' : 'var(--stroke)'),
                         background: i === src ? 'rgba(110,168,255,0.10)' : 'transparent',
                         boxShadow: i === src ? '0 0 12px var(--glow-soft)' : 'none',
                       }}>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 4 }}>
                      <span style={{ color: i === src ? 'var(--neon)' : 'var(--text-faint)' }}>{i === src ? '►' : '○'}</span>
                      <span style={{ fontFamily: 'var(--mono)', color: i === src ? 'var(--neon-1)' : 'var(--text)', fontSize: 12, letterSpacing: 0.5, textTransform: 'uppercase', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                        {i+1}. {s.name}
                      </span>
                    </div>
                    <div style={{ display: 'flex', gap: 6, fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-soft)', textTransform: 'uppercase', letterSpacing: 1 }}>
                      <span className="tag cyan">{s.kind}</span>
                      <span>· {s.dur}</span>
                      <span>· {s.q} qualities</span>
                    </div>
                  </div>
                ))}
              </div>
              {/* Qualities */}
              <div style={{ padding: 14 }}>
                <div className="panel-head">Quality</div>
                {qualities.map((qty, i) => (
                  <div key={qty.name}
                       onClick={() => setQ(i)}
                       style={{
                         padding: '6px 8px', marginBottom: 4, cursor: 'pointer',
                         display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                         border: '1px solid ' + (i === q ? 'var(--neon)' : 'transparent'),
                         background: i === q ? 'rgba(110,168,255,0.12)' : 'transparent',
                         boxShadow: i === q ? '0 0 10px var(--glow-soft)' : 'none',
                       }}>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <span style={{ color: i === q ? 'var(--neon)' : 'var(--text-faint)' }}>{i === q ? '►' : ' '}</span>
                      <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color: i === q ? 'var(--neon-1)' : 'var(--text)', letterSpacing: 0.5 }}>{qty.name}</span>
                      <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-soft)' }}>({qty.label})</span>
                    </div>
                    <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-faint)' }}>{qty.bps}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer left={<>
        <span><K>←→</K> Panel</span>
        <span><K>↑↓</K> Navigate</span>
        <span><K>↵</K> Select</span>
        <span><K>ESC</K> Cancel</span>
      </>} right={<BackendStrip />} />
    </div>
  );
}

// =================================================================
// LOADING — duck icon (no emoji)
// =================================================================
function LoadingScreen({ density = 'cozy' }) {
  return (
    <div className="app" data-density={density}>
      <Titlebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22 }}>
        <Banner size="lg" style={{ marginBottom: 8 }} />
        <div className="duck-loader" style={{ background: "url('assets/duck-icon.png') center/contain no-repeat", imageRendering: 'pixelated', width: 72, height: 72 }} />
        <div style={{ fontFamily: 'var(--mono)', fontSize: 14, color: 'var(--neon-1)', textTransform: 'uppercase', letterSpacing: 3 }}>
          Loading WaterMedia…
        </div>
        <div style={{ width: 380, height: 8, border: '1px solid var(--neon-2)', position: 'relative', background: 'var(--bg-2)', boxShadow: '0 0 8px var(--glow-soft) inset' }}>
          <div style={{ position: 'absolute', inset: 0, width: '62%', background: 'linear-gradient(90deg, var(--neon-2), var(--neon-1))', boxShadow: '0 0 10px var(--glow)' }} />
        </div>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text-soft)', lineHeight: 1.8, minWidth: 380 }}>
          <div><span style={{ color: 'var(--green)' }}>[ok]</span> init OpenGL context</div>
          <div><span style={{ color: 'var(--text-faint)' }}>[..]</span> load <span style={{ color: 'var(--text-faint)' }}>FFMpeg</span> backend</div>
          <div style={{ color: 'var(--text-faint)' }}>[ ] mount cache</div>
          <div style={{ color: 'var(--text-faint)' }}>[ ] indexing media</div>
          <div style={{ color: 'var(--text-faint)' }}>[ ] register shaders</div>
        </div>
      </div>
      <Footer left={<><span><K>ESC</K> Cancel</span></>} right={<BackendStrip states={{ ffmpeg: 'loading', opengl: true, vulkan: false }} />} />
    </div>
  );
}

// =================================================================
// SETTINGS — sidebar + form
// =================================================================
function SettingsScreen({ density = 'cozy' }) {
  const sections = ['General','Playback','Cache','Network','Renderer','Hotkeys','About'];
  const [active, setActive] = useS(1);

  return (
    <div className="app" data-density={density}>
      <Titlebar title="WATERMeDIA — Settings" />
      <Header
        name="Settings"
        sub={sections[active].toLowerCase()}
        right={<>
          <button className="btn">Reset</button>
          <button className="btn blue focus">Save <span className="hk">⌘S</span></button>
        </>}
      />

      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <aside style={{ width: 200, borderRight: '1px solid var(--stroke-bright)', padding: 14, background: 'rgba(10,15,36,0.4)', display: 'flex', flexDirection: 'column', gap: 6 }}>
          {sections.map((s, i) => (
            <div key={s}
                 onClick={() => setActive(i)}
                 style={{
                   padding: '8px 10px',
                   display: 'flex', alignItems: 'center', gap: 6,
                   border: '1px solid ' + (i === active ? 'var(--neon)' : 'var(--stroke)'),
                   background: i === active ? 'rgba(110,168,255,0.10)' : 'transparent',
                   color: i === active ? 'var(--neon-1)' : 'var(--text)',
                   fontFamily: 'var(--mono)', fontSize: 12,
                   textTransform: 'uppercase', letterSpacing: 1,
                   cursor: 'pointer',
                   boxShadow: i === active ? '0 0 12px var(--glow-soft)' : 'none',
                 }}>
              <span className="sel-cube" data-on={i === active ? 1 : 0} />
              <span>{s}</span>
            </div>
          ))}
        </aside>

        <div style={{ flex: 1, padding: 18, overflow: 'auto' }}>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 16, color: 'var(--neon-1)', textTransform: 'uppercase', letterSpacing: 2, marginBottom: 14 }}>
            ▌ Playback
          </div>

          <SettingRow k="Default volume" v={
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <div style={{ width: 200, height: 6, background: 'var(--bg-3)', position: 'relative' }}>
                <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '100%', background: 'linear-gradient(90deg, var(--neon-2), var(--neon-1))', boxShadow: '0 0 10px var(--glow)' }} />
                <div style={{ position: 'absolute', left: 'calc(100% - 2px)', top: -3, width: 4, height: 12, background: 'var(--amber)', boxShadow: '0 0 8px rgba(255,194,102,0.9)' }} />
              </div>
              <span style={{ color: 'var(--neon-1)' }}>100%</span>
            </div>
          } />
          <SettingRow k="Default quality" v={
            <select className="btn" style={{ padding: '4px 10px', fontSize: 12, background: 'var(--bg-2)', color: 'var(--neon-1)' }}>
              <option>AUTO</option><option>1080p</option><option>720p</option><option>480p</option>
            </select>
          } />
          <SettingRow k="Hardware decode" v={<Toggle on />} />
          <SettingRow k="Loop GIFs" v={<Toggle />} />
          <SettingRow k="Renderer backend" v={
            <BackendStrip />
          } />
          <SettingRow k="Cache limit" v={
            <div className="num-input">
              <input type="text" defaultValue="2048" />
              <span className="num-input-suffix">MB</span>
            </div>
          } />
          <SettingRow k="Upload Logs" v={
            <span style={{ display: 'inline-flex', gap: 6, alignItems: 'center', color: 'var(--text-faint)' }}>
              <LineIcon name="lock" size={12} /> minecraft-only
            </span>
          } />
        </div>
      </div>

      <Footer
        left={<>
          <span><K>↑↓</K> Section</span>
          <span><K>Tab</K> Field</span>
          <span><K>⌘S</K> Save</span>
          <span><K>ESC</K> Discard</span>
        </>}
        right={<BackendStrip />}
      />
    </div>
  );
}

function SettingRow({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px dashed var(--stroke)', gap: 16 }}>
      <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--text-soft)', textTransform: 'uppercase', letterSpacing: 1 }}>{k}</span>
      <div>{v}</div>
    </div>
  );
}

function Toggle({ on }) {
  return (
    <div style={{
      width: 44, height: 20, position: 'relative',
      border: '1px solid var(--neon-1)',
      background: on ? 'rgba(110,168,255,0.10)' : 'var(--bg-2)',
      boxShadow: on ? '0 0 10px var(--glow-soft)' : 'none',
      cursor: 'pointer',
    }}>
      <div style={{
        position: 'absolute', top: 1, left: on ? 24 : 1,
        width: 16, height: 16,
        background: on ? 'var(--amber)' : 'var(--neon-1)',
        boxShadow: on ? '0 0 8px rgba(255,194,102,0.7)' : '0 0 6px var(--glow-soft)',
        transition: 'left 0.2s',
      }} />
    </div>
  );
}

Object.assign(window, { MediaSelectorScreen, SourcesScreen, LoadingScreen, SettingsScreen });

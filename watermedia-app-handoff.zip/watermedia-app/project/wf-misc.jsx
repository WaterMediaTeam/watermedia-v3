/* global React, Titlebar, Footer, Key, PixelIcon, Annotation */
// Sources/Qualities + Loading + Settings — 4 variations of each (combined).

// ============ SOURCES / QUALITIES ============
function SourcesV1() {
  // Better hierarchy: source list (left) + quality stack right with bitrate hints
  return (
    <div className="wf" style={{ background: '#1a1a1a', color: '#eee' }}>
      <Titlebar />
      <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#222' }} className="crt">
        <span style={{ color: '#666', fontFamily: 'var(--mono)' }}>[ video dimmed ]</span>
        {/* Centered modal */}
        <div className="wf-box thick" style={{ width: 540, background: 'var(--paper-warm)', color: 'var(--ink)', borderColor: 'var(--c-info)', boxShadow: '0 0 24px rgba(110,168,255,0.3)', padding: 0, display: 'grid', gridTemplateColumns: '1.6fr 1fr' }}>
          <div style={{ borderRight: '2px solid var(--ink)', padding: 14 }}>
            <div className="wf-section-label" style={{ fontSize: 16 }}>Sources</div>
            <div className="wf-box" style={{ padding: 8, marginTop: 6, background: 'rgba(110,168,255,0.15)', borderColor: 'var(--c-info)' }}>
              <div style={{ fontFamily: 'var(--hand-bold)', color: 'var(--c-info-bright)' }}>1. LA BALADA DE AURONPLAY</div>
              <div className="wf-note" style={{ fontSize: 12 }}>VIDEO · 4:04 · 8 qualities</div>
            </div>
          </div>
          <div style={{ padding: 14 }}>
            <div className="wf-section-label" style={{ fontSize: 16 }}>Quality</div>
            {[['144p','low','60kb'],['360p','med','220kb'],['720p','HD','620kb'],['1080p','FHD','1.2MB','focus']].map(([q,l,br,f],i)=>(
              <div key={i} style={{ display:'flex', justifyContent:'space-between', padding: '4px 6px', background: f?'rgba(110,168,255,0.15)':'transparent', border: f?'1.5px solid var(--c-info)':'none', marginBottom: 2 }}>
                <span style={{ fontFamily:'var(--hand-bold)' }}>{q}</span>
                <span className="wf-note" style={{ fontSize: 11 }}>{l} · {br}/s</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <Footer><Key>←→</Key> Panel · <Key>↑↓</Key> Pick · <Key>↵</Key> Confirm</Footer>
    </div>
  );
}

function SourcesV2() {
  // Bottom sheet: source tabs across top, qualities as horizontal pills below
  return (
    <div className="wf" style={{ background: '#1a1a1a', color: '#eee' }}>
      <Titlebar />
      <div style={{ flex: 1, background: '#222', display:'flex', alignItems:'center', justifyContent:'center', color:'#666', fontFamily:'var(--mono)' }} className="crt">
        [ video keeps playing ]
      </div>
      <div style={{ background: '#08101e', borderTop: '2px solid var(--c-neon)', padding: 12, color: '#fff' }}>
        <div style={{ display:'flex', gap: 6, marginBottom: 8 }}>
          {['LA BALADA DE AURONPLAY','Audio only','Subtitles'].map((t,i)=>(
            <span key={i} style={{ padding:'4px 10px', border:`1.5px solid ${i===0?'var(--c-neon)':'#444'}`, color: i===0?'var(--c-neon)':'#888', fontFamily:'var(--mono)', fontSize: 12 }}>{t}</span>
          ))}
        </div>
        <div style={{ display:'flex', gap: 6, flexWrap:'wrap' }}>
          {['144p','360p','480p','720p','1080p','1440p','4K','auto'].map((q,i)=>(
            <span key={i} style={{ padding:'6px 12px', border:`1.5px solid ${i===4?'var(--c-cyan)':'#555'}`, color:i===4?'var(--c-cyan)':'#aaa', fontFamily:'var(--mono)', fontSize: 13, background: i===4?'rgba(45,212,255,0.1)':'transparent', boxShadow: i===4?'0 0 10px rgba(45,212,255,0.4)':'none' }}>{q}</span>
          ))}
        </div>
      </div>
      <Footer><Key>1-9</Key> Pick quality · <Key>S</Key> Source</Footer>
    </div>
  );
}

// ============ LOADING ============
function LoadingV1() {
  // Pixel duck spinner + status log
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ flex: 1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap: 14 }}>
        <div style={{ width: 80, height: 80, border: '3px solid var(--ink)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--mono)', fontSize: 11 }}>
          <span style={{ animation: 'spin 1s linear infinite', display:'inline-block', fontSize: 28 }}>🦆</span>
        </div>
        <div style={{ fontFamily:'var(--hand-bold)', fontSize: 22 }}>Loading WaterMedia…</div>
        <div style={{ width: 360, height: 12, border:'2px solid var(--ink)', position:'relative', background: 'var(--paper-warm)' }}>
          <div style={{ position:'absolute', inset:0, width:'62%', background: 'repeating-linear-gradient(45deg, var(--c-neon), var(--c-neon) 6px, var(--c-info) 6px, var(--c-info) 12px)' }} />
        </div>
        <div className="wf-note" style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>
          [ok] init OpenGL ctx<br />
          [ok] load FFMpeg backend<br />
          [..] indexing 412 cached items
        </div>
      </div>
      <Footer><Key>ESC</Key> Cancel</Footer>
    </div>
  );
}

function LoadingV2() {
  // Skeleton screens — show shape of upcoming UI
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}>
        <div style={{ width: 280, height: 36, background: 'var(--paper-warm)', border: '2px dashed var(--ink-faint)' }} />
      </div>
      <div style={{ flex: 1, padding: 18 }}>
        <div style={{ width: 80, height: 18, background: 'var(--paper-warm)', marginBottom: 10 }} />
        <div style={{ display:'flex', gap: 12, marginBottom: 22 }}>
          {[0,1,2,3].map(i=>(
            <div key={i} style={{ flex:1, minHeight: 86, background: 'var(--paper-warm)', border:'2px dashed var(--ink-faint)', position:'relative', overflow:'hidden' }}>
              <div style={{ position:'absolute', inset:0, background:'linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent)', animation:'shimmer 1.4s infinite' }} />
            </div>
          ))}
        </div>
        <div style={{ width: 100, height: 18, background: 'var(--paper-warm)', marginBottom: 10 }} />
        <div style={{ display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap: 10 }}>
          {[...Array(6)].map((_,i)=><div key={i} style={{ minHeight:70, background:'var(--paper-warm)', border:'2px dashed var(--ink-faint)' }} />)}
        </div>
        <Annotation arrow="up" style={{ marginTop: 10 }}>Skeletons match real layout — no jarring layout shift</Annotation>
      </div>
      <Footer><Key>ESC</Key> Cancel</Footer>
      <style>{`@keyframes shimmer{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

// ============ SETTINGS ============
function SettingsV1() {
  return (
    <div className="wf" data-density="cozy">
      <Titlebar />
      <div style={{ padding: '12px 18px', borderBottom: '2px solid var(--ink)' }}>
        <div className="wf-section-label" style={{ margin:0 }}>Settings</div>
      </div>
      <div style={{ flex: 1, display:'flex', minHeight: 0 }}>
        <aside style={{ width: 180, borderRight: '2px solid var(--ink)', padding: 10, background: 'var(--paper-warm)' }}>
          {['General','Playback','Cache','Network','Renderer','About'].map((s,i)=>(
            <div key={i} style={{ padding: '6px 8px', borderLeft: i===1?'3px solid var(--c-info)':'3px solid transparent', fontFamily:'var(--hand-bold)', fontSize: 16, background: i===1?'rgba(110,168,255,0.15)':'transparent' }}>{s}</div>
          ))}
        </aside>
        <div style={{ flex:1, padding: 16 }}>
          <div style={{ fontFamily:'var(--hand-bold)', fontSize: 20, marginBottom: 12 }}>Playback</div>
          {[
            ['Default volume', '100%'],
            ['Default quality', 'Auto'],
            ['Hardware decode', 'On  ●○'],
            ['Renderer backend', 'OpenGL · (Vulkan soon)'],
            ['Loop GIFs', 'On'],
          ].map(([k,v],i)=>(
            <div key={i} style={{ display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:'1px dashed var(--ink-faint)' }}>
              <span style={{ fontFamily:'var(--hand-bold)' }}>{k}</span>
              <span className="wf-note">{v}</span>
            </div>
          ))}
        </div>
      </div>
      <Footer><Key>Tab</Key> Section · <Key>↵</Key> Edit · <Key>S</Key> Save</Footer>
    </div>
  );
}

function SettingsV2() {
  // Single column, terminal-styled
  return (
    <div className="wf" style={{ background: '#08101e', color: '#e8e6f5' }}>
      <div style={{ height: 28, background:'#0e1422', borderBottom:'1px solid #6ea8ff', color:'#6ea8ff', fontFamily:'var(--mono)', fontSize:13, padding:'0 12px', display:'flex', alignItems:'center' }}>◆ SETTINGS</div>
      <div style={{ flex:1, padding: 18, fontFamily: 'var(--mono)', fontSize: 14, lineHeight: 1.9 }}>
        {[
          ['volume','100','int'],
          ['quality','auto','enum'],
          ['hwdecode','true','bool'],
          ['backend','opengl','enum [opengl|vulkan*]'],
          ['cache.size','2048','MB'],
          ['log.upload','minecraft-only','readonly'],
        ].map(([k,v,t],i)=>(
          <div key={i} style={{ display:'flex', gap: 14, color: i===3?'#2dd4ff':'#fff' }}>
            <span style={{ color: '#888', width: 140 }}>{k}</span>
            <span style={{ color: '#4ade80' }}>=</span>
            <span style={{ color: '#6ea8ff' }}>{v}</span>
            <span style={{ color: '#666', marginLeft:'auto' }}>// {t}</span>
          </div>
        ))}
      </div>
      <div style={{ borderTop:'1px solid #6ea8ff', padding:'6px 14px', fontFamily:'var(--mono)', fontSize:12, color:'#6ea8ff' }}>[E] EDIT · [S] SAVE · [R] RESET</div>
    </div>
  );
}

Object.assign(window, { SourcesV1, SourcesV2, LoadingV1, LoadingV2, SettingsV1, SettingsV2 });

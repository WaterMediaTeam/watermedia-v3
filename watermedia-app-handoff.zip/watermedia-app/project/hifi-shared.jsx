/* global React */
// Hi-fi shared bits: titlebar, footer, pixel icons, status, transport.

const { useState, useEffect, useRef, Fragment } = React;

function Titlebar({ title = "WATERMeDIA — Multimedia API" }) {
  return (
    <div className="app-titlebar">
      <div className="duck-mini" />
      <span className="title">{title}</span>
      <span className="winctrl">
        <span title="Minimize">—</span>
        <span title="Maximize">▢</span>
        <span title="Close">✕</span>
      </span>
    </div>
  );
}

function Footer({ left, right }) {
  return (
    <div className="app-footer">
      {left}
      {right && <div style={{ marginLeft: 'auto', display: 'flex', gap: 14, alignItems: 'center' }}>{right}</div>}
    </div>
  );
}

// Unified screen header — banner + amber separator + screen name + right slot
function Header({ name, sub, right, bannerSize = 'md' }) {
  return (
    <div className="app-header">
      <Banner size={bannerSize} />
      <span className="amber-sep" />
      <div className="hdr-name">
        <span>{name}</span>
        {sub && <span className="hdr-sub">{sub}</span>}
      </div>
      {right && <div className="hdr-right">{right}</div>}
    </div>
  );
}

// Backend availability tag — green if on, red strike if off, gray when loading
function BackendTag({ name, on, loading }) {
  const cls = loading ? 'pending' : (on ? 'on' : 'off');
  return (
    <span className={"backend-tag " + cls} title={name + (loading ? ' — loading…' : on ? " — available" : " — unavailable")}>
      <span className="bt-dot" />
      <span className="bt-name">{name}</span>
    </span>
  );
}

function BackendStrip({ states }) {
  // states: { ffmpeg: true|false|'loading', opengl: ..., vulkan: ... }
  const s = states || { ffmpeg: true, opengl: true, vulkan: false };
  const norm = v => ({ on: v === true, loading: v === 'loading' });
  const f = norm(s.ffmpeg), g = norm(s.opengl), v = norm(s.vulkan);
  return (
    <div className="backend-strip">
      <BackendTag name="FFMPEG" on={f.on} loading={f.loading} />
      <BackendTag name="OpenGL" on={g.on} loading={g.loading} />
      <BackendTag name="Vulkan" on={v.on} loading={v.loading} />
    </div>
  );
}

function K({ children }) { return <span className="key">{children}</span>; }

// Pixel-art glyphs via inline SVG rects (sharper than box-shadows for retina)
function PixIcon({ name = 'play', size = 16, color = 'currentColor' }) {
  const G = {
    play: ['1000','1100','1110','1111','1110','1100','1000'],
    pause: ['11011','11011','11011','11011','11011'],
    stop: ['11111','11111','11111','11111','11111'],
    folder: ['110000','111111','100001','100001','111111'],
    upload: ['001100','011110','110011','001100','001100','001100'],
    broom: ['00010','00100','01110','11111','10101','10101'],
    x: ['10001','01010','00100','01010','10001'],
    settings: ['0110','1111','1001','1111','0110'],
    next: ['1000','1100','1110','1111','1110','1100','1000'],
    prev: ['0001','0011','0111','1111','0111','0011','0001'],
    arrow: ['0010','0011','1111','0011','0010'],
    cog: ['01010','11111','10001','11111','01010'],
    info: ['010','000','010','010','010'],
    warn: ['00100','01010','10001','11111','11111'],
    eye: ['01110','11111','11011','11111','01110'],
    cache: ['11111','10001','01010','10001','11111'],
    speaker: ['00110','01110','11110','01110','00110'],
    fullscreen: ['11011','10001','00000','10001','11011'],
  };
  const grid = G[name] || G.play;
  const cols = grid[0].length;
  const cell = Math.max(1, Math.floor(size / Math.max(grid.length, cols)));
  return (
    <svg
      width={cols * cell}
      height={grid.length * cell}
      viewBox={`0 0 ${cols * cell} ${grid.length * cell}`}
      style={{ display: 'inline-block', verticalAlign: 'middle' }}
      shapeRendering="crispEdges"
      aria-hidden="true"
    >
      {grid.map((row, y) =>
        [...row].map((c, x) =>
          c === '1' ? (
            <rect key={`${x}-${y}`} x={x * cell} y={y * cell} width={cell} height={cell} fill={color} />
          ) : null
        )
      )}
    </svg>
  );
}

// Linear stroke icon for utility/abstract concepts
function LineIcon({ name, size = 16 }) {
  const I = {
    gear: <><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M4 12H1M23 12h-3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6"/><circle cx="12" cy="8" r="0.6" fill="currentColor"/></>,
    warn: <><path d="M12 3 L22 21 L2 21 Z"/><path d="M12 10v5"/><circle cx="12" cy="18" r="0.6" fill="currentColor"/></>,
    eye: <><path d="M2 12 C5 6, 19 6, 22 12 C19 18, 5 18, 2 12 Z"/><circle cx="12" cy="12" r="3"/></>,
    search: <><circle cx="11" cy="11" r="6"/><line x1="20" y1="20" x2="16" y2="16"/></>,
    link: <><path d="M9 15l6-6"/><path d="M14 7a4 4 0 1 1 4 4l-2 2"/><path d="M10 17a4 4 0 1 1-4-4l2-2"/></>,
    lock: <><rect x="5" y="11" width="14" height="9"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></>,
    upload: <><path d="M12 18V4"/><path d="M5 11l7-7 7 7"/><path d="M4 20h16"/></>,
    refresh: <><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/></>,
    check: <><path d="M4 12l5 5L20 6"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ verticalAlign: 'middle' }} aria-hidden="true">
      {I[name] || I.info}
    </svg>
  );
}

// CRT video surface w/ scanlines + faint moving line
function VideoSurface({ children, dim = false }) {
  return (
    <div style={{ position: 'absolute', inset: 0, background: '#0a0e1a', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, opacity: dim ? 0.35 : 1, background: 'linear-gradient(135deg, #1a2348 0%, #0a0e1a 60%)' }} />
      {children}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'repeating-linear-gradient(0deg, transparent 0, transparent 2px, rgba(0,0,0,0.22) 2px, rgba(0,0,0,0.22) 3px)' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, height: 60, background: 'linear-gradient(180deg, rgba(110,168,255,0.18), transparent)', pointerEvents: 'none', animation: 'scan 6s linear infinite' }} />
    </div>
  );
}

// Brand banner element
function Banner({ size = 'md', style }) {
  const cls = size === 'sm' ? 'brand-banner sm' : size === 'lg' ? 'brand-banner lg' : 'brand-banner';
  return <div className={cls} role="img" aria-label="WATERMeDIA" style={style} />;
}

Object.assign(window, { Titlebar, Footer, Header, BackendTag, BackendStrip, K, PixIcon, LineIcon, VideoSurface, Banner });

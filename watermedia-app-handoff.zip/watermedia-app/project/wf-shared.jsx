/* global React */
// Shared wireframe primitives — sketchy SVG filter, titlebar, footer, logo, icons.

const { Fragment } = React;

// SVG filter for hand-drawn wobble — injected once at the top of the page.
function WFRoughDefs() {
  return (
    <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden="true">
      <defs>
        <filter id="wf-rough">
          <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="2" seed="3" />
          <feDisplacementMap in="SourceGraphic" scale="1.6" />
        </filter>
        <filter id="wf-rough-strong">
          <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="2" seed="7" />
          <feDisplacementMap in="SourceGraphic" scale="2.4" />
        </filter>
      </defs>
    </svg>
  );
}

function Titlebar({ title = "WATERMeDIA: Multimedia API" }) {
  return (
    <div className="wf-titlebar">
      <span className="tb-dot" />
      <span className="tb-title">{title}</span>
      <span className="tb-controls">
        <span>—</span>
        <span>▢</span>
        <span>✕</span>
      </span>
    </div>
  );
}

function Footer({ children }) {
  return <div className="wf-footer">{children}</div>;
}

function Key({ children }) {
  return <span className="key">{children}</span>;
}

// Real logo — uses the banner asset
function Logo({ size = 'md' }) {
  const cls = size === 'sm' ? 'wf-banner sm' : size === 'lg' ? 'wf-banner lg' : 'wf-banner';
  return <div className={cls} role="img" aria-label="WATERMEDIA" />;
}

// Just the duck icon
function DuckIcon({ size = 32 }) {
  return (
    <span
      style={{
        width: size, height: size, display: 'inline-block', flexShrink: 0,
        backgroundImage: "url('assets/duck-icon.png')",
        backgroundSize: 'contain',
        backgroundRepeat: 'no-repeat',
        imageRendering: 'pixelated',
      }}
      aria-hidden="true"
    />
  );
}

// Pixel-art glyph drawn via box-shadow (cheap, sketchy)
function PixelIcon({ shape = 'play', color = 'currentColor', size = 14 }) {
  const grids = {
    play: [
      [1,0,0,0],
      [1,1,0,0],
      [1,1,1,0],
      [1,1,1,1],
      [1,1,1,0],
      [1,1,0,0],
      [1,0,0,0],
    ],
    folder: [
      [1,1,0,0,0,0],
      [1,1,1,1,1,1],
      [1,0,0,0,0,1],
      [1,0,0,0,0,1],
      [1,1,1,1,1,1],
    ],
    upload: [
      [0,0,1,1,0,0],
      [0,1,1,1,1,0],
      [1,1,0,0,1,1],
      [0,0,1,1,0,0],
      [0,0,1,1,0,0],
      [0,0,1,1,0,0],
    ],
    broom: [
      [0,0,0,1,0],
      [0,0,1,0,0],
      [0,1,1,1,0],
      [1,1,1,1,1],
      [1,0,1,0,1],
      [1,0,1,0,1],
    ],
    x: [
      [1,0,0,0,1],
      [0,1,0,1,0],
      [0,0,1,0,0],
      [0,1,0,1,0],
      [1,0,0,0,1],
    ],
    pause: [
      [1,1,0,1,1],
      [1,1,0,1,1],
      [1,1,0,1,1],
      [1,1,0,1,1],
      [1,1,0,1,1],
    ],
    settings: [
      [0,1,1,0],
      [1,1,1,1],
      [1,0,0,1],
      [1,1,1,1],
      [0,1,1,0],
    ],
  };
  const grid = grids[shape] || grids.play;
  const cell = Math.max(2, Math.floor(size / grid.length));
  return (
    <span
      className="pix-ico"
      style={{
        width: grid[0].length * cell,
        height: grid.length * cell,
        display: 'inline-block',
        position: 'relative',
      }}
      aria-hidden="true"
    >
      {grid.map((row, y) =>
        row.map((on, x) =>
          on ? (
            <span
              key={`${x}-${y}`}
              style={{
                position: 'absolute',
                left: x * cell,
                top: y * cell,
                width: cell,
                height: cell,
                background: color,
              }}
            />
          ) : null
        )
      )}
    </span>
  );
}

// Annotation: scribbled note with optional arrow
function Annotation({ children, arrow = null, style }) {
  return (
    <div className="wf-note" style={{ display: 'flex', gap: 6, alignItems: 'flex-start', ...style }}>
      {arrow === 'left' && <span className="wf-arrow">←</span>}
      {arrow === 'up' && <span className="wf-arrow">↑</span>}
      <span>{children}</span>
      {arrow === 'right' && <span className="wf-arrow">→</span>}
      {arrow === 'down' && <span className="wf-arrow">↓</span>}
    </div>
  );
}

function VarHead({ name, tag }) {
  return (
    <div className="wf-varhead">
      {name}
      {tag && <span className="tag">{tag}</span>}
    </div>
  );
}

Object.assign(window, { WFRoughDefs, Titlebar, Footer, Key, Logo, DuckIcon, PixelIcon, Annotation, VarHead });

/* global React, Titlebar, Footer, K, PixIcon, LineIcon, VideoSurface, BackendStrip */
// Player screen — redesigned to eliminate redundancy.
// Each fact appears ONCE: title (top), time/duration (scrubber only), quality (right-side
// of transport), status (left of transport via play/pause icon + small pip), size+speed
// stacked into the Debug toggle button. Debug rail is COMPACT (no metadata duplication).

const { useState } = React;

function PlayerScreen({ density = 'cozy' }) {
  const [hudOn, setHudOn] = useState(true);
  const [debugOpen, setDebugOpen] = useState(true);
  const [playing, setPlaying] = useState(true);

  return (
    <div className="app" data-density={density} style={{ background: '#06091a' }}>
      <Titlebar title="WATERMeDIA — Now Playing" />

      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}
           onMouseMove={() => setHudOn(true)}>
        <VideoSurface>
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-faint)', fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: 2 }}>
            [ video stream ]
          </div>
        </VideoSurface>

        {/* TOP BAR — title + author only. No status/quality (lives in transport). */}
        <div className={'player-top ' + (hudOn ? 'show' : '')}>
          <button className="btn" style={{ padding: '4px 10px', fontSize: 11 }}>
            <LineIcon name="link" size={12} /> Back
          </button>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 14, color: 'var(--text)', letterSpacing: 0.5, textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap', textShadow: '0 0 12px rgba(0,0,0,0.85)' }}>
              LA BALADA DE AURONPLAY
            </div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text-soft)', textTransform: 'uppercase', letterSpacing: 1.5, marginTop: 2 }}>
              Lucas Requena · YouTube · 2021-01-22
            </div>
          </div>
          <button className="btn" style={{ padding: '4px 10px', fontSize: 11 }} title="Sources">
            <PixIcon name="folder" size={10} /> 1/1
          </button>
          <span className="size-chip" title="Resolution">1920×1080</span>
          <button
            className={'btn ' + (debugOpen ? 'focus blue' : '')}
            style={{ padding: '4px 10px', fontSize: 11 }}
            onClick={() => setDebugOpen(!debugOpen)}
            title="Debug panel"
          >
            <LineIcon name="info" size={11} /> Debug {debugOpen ? '◀' : '▶'}
          </button>
        </div>

        {/* DEBUG RAIL — compact, ONLY engine-level facts not visible elsewhere */}
        {debugOpen && (
          <div className={'player-debug ' + (hudOn ? 'show' : '')}>
            <div className="panel-head" style={{ marginBottom: 8 }}>Engine</div>
            <Row k="Engine"  v="FFMediaPlayer" />
            <Row k="Buffer"  v="3.2 MB · 4s" />
            <Row k="FPS"     v="60.0" color="var(--green)" />
            <Row k="Decode"  v="HW (NVDEC)" color="var(--cyan)" />
            <Row k="Latency" v="12 ms" />
            <Row k="Live"    v="No" />
            <Row k="Loops"   v="0" />

            <div className="panel-head" style={{ margin: '14px 0 8px', borderTop: '1px dashed var(--stroke)', paddingTop: 12 }}>Metadata</div>
            <Row k="Title" v="LA BALADA DE AURONPLAY" />
            <Row k="MRL" v="youtube.com/watch?v=…" mono />
            <Row k="Source" v="YouTube" color="var(--cyan)" />
            <div style={{ marginTop: 6, padding: '8px 10px', border: '1px dashed var(--stroke)', background: 'var(--bg-2)' }}>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 9, color: 'var(--text-faint)', textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 4 }}>Description</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text-soft)', lineHeight: 1.5, maxHeight: 64, overflow: 'hidden' }}>
                Cancion oficial del Auronplay tocando la guitarra cantando la balada… contiene rifa, bots, y mucho amor para el creador.
              </div>
            </div>
          </div>
        )}

        {/* TRANSPORT BAR */}
        <div className={'player-transport ' + (hudOn ? 'show' : '')}>
          {/* Scrubber: time/duration ONLY here */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--neon-1)', minWidth: 42, textAlign: 'right' }}>00:01</span>
            <div style={{ flex: 1, height: 6, background: 'var(--bg-3)', position: 'relative', cursor: 'pointer' }}>
              {/* buffered */}
              <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '14%', background: 'rgba(110,168,255,0.22)' }} />
              {/* played */}
              <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '8%', background: 'linear-gradient(90deg, var(--neon-2), var(--neon-1))', boxShadow: '0 0 10px var(--glow)' }} />
              {/* amber playhead */}
              <div style={{ position: 'absolute', left: '8%', top: -3, width: 4, height: 12, background: 'var(--amber)', boxShadow: '0 0 8px rgba(255,194,102,0.9)' }} />
            </div>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text-soft)', minWidth: 42 }}>04:04</span>
          </div>

          {/* Controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <button className="btn" style={btnSm} title="Previous source"><PixIcon name="prev" size={10} /></button>
            <button className="btn" style={btnSm} title="Seek -10s">
              <span style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}>
                <PixIcon name="prev" size={10} />
                <span style={{ position: 'absolute', left: 12, fontSize: 8, color: 'var(--text-soft)', letterSpacing: 0 }}>10</span>
              </span>
            </button>
            <button
              className="btn focus blue"
              style={{ ...btnSm, padding: 9, minWidth: 42, position: 'relative' }}
              onClick={() => setPlaying(!playing)}
              title={playing ? 'Pause' : 'Play'}
            >
              <PixIcon name={playing ? 'pause' : 'play'} size={12} color="var(--neon-1)" />
              <span className="pip ok" style={{ position: 'absolute', top: 4, right: 4, width: 5, height: 5 }} />
            </button>
            <button className="btn" style={btnSm} title="Seek +10s">
              <span style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}>
                <span style={{ position: 'absolute', right: 12, fontSize: 8, color: 'var(--text-soft)', letterSpacing: 0 }}>10</span>
                <PixIcon name="next" size={10} />
              </span>
            </button>
            <button className="btn" style={btnSm} title="Next source"><PixIcon name="next" size={10} /></button>
            <button className="btn" style={btnSm} title="Stop"><PixIcon name="stop" size={10} color="var(--red)" /></button>

            <Sep />

            <button className="btn" style={btnSm}><PixIcon name="speaker" size={12} /></button>
            <div style={{ width: 70, height: 4, background: 'var(--bg-3)', position: 'relative' }}>
              <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '100%', background: 'var(--neon)' }} />
            </div>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text-soft)', minWidth: 32 }}>100</span>

            <Sep />

            <button className="btn" style={{ ...btnSm, padding: '6px 10px' }} title="Speed">1.0×</button>
            <button className="btn cyan" style={{ ...btnSm, padding: '6px 10px', borderColor: 'var(--cyan)', color: 'var(--cyan)' }} title="Quality">1080p</button>
            <button className="btn" style={{ ...btnSm, padding: '6px 10px' }} title="Loop">↻</button>

            <div style={{ flex: 1 }} />

            <button className="btn" style={btnSm} title="Picture-in-picture"><span style={{ fontSize: 11 }}>⊟</span></button>
            <button className="btn" style={btnSm} title="Fullscreen"><PixIcon name="fullscreen" size={12} /></button>
          </div>
        </div>
      </div>

      <Footer
        left={<>
          <span><K>SPACE</K> Play</span>
          <span><K>←→</K> Seek 10s</span>
          <span><K>↑↓</K> Volume</span>
          <span><K>D</K> Debug</span>
          <span><K>F</K> Fullscreen</span>
          <span><K>ESC</K> Back</span>
        </>}
        right={<BackendStrip />}
      />
    </div>
  );
}

const btnSm = { padding: 6, minWidth: 32 };
function Sep() {
  return <div style={{ width: 1, height: 22, background: 'var(--stroke-bright)', margin: '0 6px' }} />;
}
function Row({ k, v, color, mono }) {
  return (
    <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between', fontSize: 11, lineHeight: 1.7 }}>
      <span style={{ color: 'var(--text-faint)' }}>{k}</span>
      <span style={{ color: color || 'var(--text)', fontFamily: mono ? 'var(--mono)' : undefined, textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap', maxWidth: 150 }}>{v}</span>
    </div>
  );
}

Object.assign(window, { PlayerScreen });
